IF DB_ID('CAR_PARK') IS NOT NULL

BEGIN
	USE master
	DROP DATABASE CAR_PARK
END
GO

CREATE DATABASE CAR_PARK
GO

USE CAR_PARK
GO

CREATE TABLE EMPLOYEE(
	employee_id		BIGINT			IDENTITY(1,1),
	full_name		NVARCHAR(50), 
	dob				DATE,
	sex				BIT,
	[address]		NVARCHAR(50), 
	phone_number	VARCHAR(50),
	email			VARCHAR(50),
	account			VARCHAR(50),
	[password]		VARCHAR(100),
	department		VARCHAR(20),

	CONSTRAINT		PK_Employee_ID	PRIMARY KEY (employee_id)
)
GO

CREATE TABLE PARKINGLOT(
	park_id		BIGINT				IDENTITY(1,1),
	name_park	VARCHAR(50),
	place		VARCHAR(11),
	area		BIGINT,
	price		BIGINT,
	status_park BIT,
	CONSTRAINT	PK_ParkingLot_Id	PRIMARY KEY (park_id)
)
GO

CREATE TABLE CAR(
	license_plate	VARCHAR(50),
	car_type		VARCHAR(10),
	car_color		VARCHAR(10),
	company			VARCHAR(50),
	park_id			BIGINT

	CONSTRAINT		PK_Car_LicenseP	PRIMARY KEY (license_plate),
	CONSTRAINT		FK_Car_parkID	FOREIGN KEY (park_id)
	REFERENCES		PARKINGLOT (park_id)
)
GO

CREATE TABLE TRIP(
	trip_id			BIGINT			IDENTITY(1,1),
	destination		NVARCHAR(50),
	depature_date	DATETIME,
	driver			VARCHAR(15),
	seat_type		VARCHAR(11),
	booked_ticket	INT,
	max_ticket		INT,

	CONSTRAINT		CHK_TRIP_TICKET	CHECK(max_ticket >= booked_ticket),
	
	CONSTRAINT		PK_Trip_ID		PRIMARY KEY (trip_id)
)
GO

CREATE TABLE TICKET(
	ticket_id		BIGINT			IDENTITY(1,1),
	cus_name		NVARCHAR(50),
	trip_id			BIGINT,
	booking_time	TIME,
	license_plate	VARCHAR(50),

	CONSTRAINT		PK_Ticket_ID			PRIMARY KEY (ticket_id),

	CONSTRAINT		FK_Ticket_Trip_ID		FOREIGN KEY (trip_id)
	REFERENCES		TRIP (trip_id),

	CONSTRAINT		FK_Ticket_LicenseP	FOREIGN KEY (license_plate)
	REFERENCES		CAR (license_plate)
)
GO

CREATE TABLE BOOK_OFFICE(
	bookoffice_id	BIGINT			IDENTITY(1,1),
	bookoffice_name NVARCHAR(50),
	phone_number	VARCHAR(50),
	price			BIGINT,
	place			NVARCHAR(50),
	trip_id			BIGINT,
	start_contract	DATE,
	end_contract	DATE,

	CONSTRAINT		PK_B_Office_ID	PRIMARY KEY (bookoffice_id),
	CONSTRAINT		FK_Book_Trip_ID	FOREIGN KEY (trip_id)
	REFERENCES		TRIP (trip_id),
)
GO

CREATE TRIGGER TRG_ADD_TICKET ON TICKET AFTER INSERT AS
BEGIN
	UPDATE TRIP
	SET booked_ticket = booked_ticket + (
		SELECT COUNT(ticket_id)
		FROM inserted
		WHERE trip_id = TRIP.trip_id
	)
	FROM TRIP JOIN inserted ON TRIP.trip_id = inserted.trip_id
END
GO

CREATE TRIGGER TRG_DELETE_TICKET ON TICKET AFTER DELETE AS
BEGIN
	UPDATE TRIP
	SET booked_ticket = booked_ticket - (
		SELECT COUNT(ticket_id)
		FROM deleted
		WHERE trip_id = TRIP.trip_id
	)
	FROM TRIP JOIN deleted ON TRIP.trip_id = deleted.trip_id
END

GO
INSERT INTO EMPLOYEE 
VALUES	('EMP1' , '06-01-2000' , 1 , 'HaNoi1' , '0213412312' , 'emp1@gmail.com' , 'emp1fpt' , '123456' , 'Admin'),
		('EMP2' , '03-02-2000' , 0 , 'HaNoi2' , '0123512312' , 'emp2@gmail.com' , 'emp2fpt' , '123456' , 'Admin'),
		('EMP3' , '10-11-2000' , 0 , 'HaNoi3' , '0346355321' , 'emp3@gmail.com' , 'emp3fpt' , '123456' , 'Emplulloyee'),
		('EMP4' , '12-01-2000' , 1 , 'HaNoi4' , '0536345345' , 'emp4@gmail.com' , 'emp4fpt' , '123456' , 'Employee'),
		('EMP5' , '05-05-2000' , 1 , 'HaNoi5' , '0623449123' , 'emp5@gmail.com' , 'emp5fpt' , '123456' , 'Employee');
GO
INSERT INTO PARKINGLOT 
VALUES	('PARK 1' , 'place 1' , '100' , 1000000 , 1),
		('PARK 2' , 'place 2' , '20' , 200000 , 0),
		('PARK 3' , 'place 3' , '120' , 150000 ,0),
		('PARK 4' , 'place 4' , '50' , 800000 , 1),
		('PARK 5' , 'place 5' , '70' , 1200000 , 0);

GO
INSERT INTO CAR 
VALUES	('LP1' , 'type 1' , 'white' , 'company 1' , 1),
		('LP2' , 'type 2' , 'blue' , 'company 2' , 1),
		('LP3' , 'type 1' , 'black' , 'company 1' , 2),
		('LP4' , 'type 3' , 'pink' , 'company 3' , 3),
		('LP5' , 'type 3' , 'grey' , 'company 4' , 4);
GO 
INSERT INTO TRIP 
VALUES	('Des 1' , '08-11-2021 08:00' , 'driver 1' , 'type 1' , 0 , 10),
		('Des 2' , '01-12-2021 10:00' , 'driver 2' , 'type 2' , 0 , 10),
		('Des 3' , '04-11-2021 13:00' , 'driver 3' , 'type 3' , 0 , 10),
		('Des 4' , '10-12-2021 04:00' , 'driver 1' , 'type 2' , 0 , 10),
		('Des 5' , '12-12-2021 05:30' , 'driver 2' , 'type 1' , 0 , 10),
		('Des 12' , '12-12-2021 08:30' , 'driver 2' , 'type 1' , 0 , 10),
		('Des 6' , '12-12-2021 02:30' , 'driver 2' , 'type 2' , 0 , 10),
		('Des 7' , '12-12-2021 05:30' , 'driver 2' , 'type 4' , 0 , 10),
		('Des 8' , '12-12-2021 03:30' , 'driver 2' , 'type 1' , 0 , 10),
		('Des 9' , '12-12-2021 09:30' , 'driver 2' , 'type 3' , 0 , 10),
		('Des 10' , '10-12-2021 21:00' , 'driver 1' , 'type 3' , 0 , 10),
		('Ha Long' , '10-12-2021 12:00' , 'driver 4' , 'type 4' , 0 , 10),
		('Quang Ngai' , '10-12-2021 14:00' , 'driver 5' , 'type 1' , 0 , 10),
		('Des 13' , '10-12-2021 14:00' , 'driver 2' , 'type 2' , 0 , 10),
		('Des 4' , '10-12-2021 15:00' , 'driver 1' , 'type 1' , 0 , 10),
		('Des 4' , '10-12-2021 04:00' , 'driver 3' , 'type 4' , 0 , 10),
		('Des 20' , '10-12-2021 03:00' , 'driver 2' , 'type 3' , 0 , 10),
		('Des 21' , '10-12-2021 11:00' , 'driver 1' , 'type 1' , 0 , 10),
		('Des 15' , '10-12-2021 06:00' , 'driver 3' , 'type 4' , 0 , 10),
		('Des 16' , '10-12-2021 02:00' , 'driver 1' , 'type 2' , 0 , 10)
GO 
INSERT INTO TICKET
VALUES	('Ticket 1' , 1 , '01-09-2021' ,  'LP1'),
		('Ticket 2' , 1 , '01-09-2021' ,  'LP1'),
		('Ticket 3' , 5 , '11-09-2021' ,  'LP2'),
		('Ticket 4' , 1 , '02-09-2021' ,  'LP4'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5'),
		('Ticket 5' , 5 , '01-09-2021' ,  'LP5')
GO
INSERT INTO BOOK_OFFICE
VALUES	('BO1'  , '0124523412' , 1000000 , 'place 1' , 1 , '03-10-2021' , '03-11-2021'),
		('BO2'  , '0234523412' , 400000 , 'place 2' , 2 , '12-10-2021' , '12-11-2021'),
		('BO3'  , '0124123895' , 1200000 , 'place 3' , 4 , '01-11-2021' , '01-12-2021'),
		('BO4'  , '0134235234' , 500000 , 'place 4' , 5 , '10-11-2021' , '01-12-2021'),
		('BO5'  , '0126767523' , 1000000 , 'place 5' , 1 , '01-10-2021' , '10-15-2021');
GO