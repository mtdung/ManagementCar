function validateDate() {
	var day = document.getElementById("day").value;
	var month = document.getElementById("month").value;
	var year = document.getElementById("year").value;
	var isValid = false;
	switch (month) {
		case "1":
			isValid =  true;
			break;
		case "2":
			if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)) {
				isValid =  (day <= 29);
				break;
			}
			isValid = (day <= 28);
			break;
		case "3":
			isValid = true;
			break;
		case "4":
			isValid = (day <= 30);
			break;
		case "5":
			isValid = true;
			break;
		case "6":
			isValid = (day <= 30);
			break;
		case "7":
			isValid = true;
			break;
		case "8":
			isValid = true;
			break;
		case "9":
			isValid = (day <= 30);
			break;
		case "10":
			isValid = true;
			break;
		case "11":
			isValid = (day <= 30);
			break;
		default:
			isValid = true;
			break;
	}
	if(!isValid){
		document.getElementById("generalAlert").innerHTML = "Please check your date!";
	}
	else{
		document.getElementById("generalAlert").innerHTML = "";
	}
	console.log(isValid);
	return isValid;
}

function deleteConfirmation(){
    return confirm("Are you sure you want to delete this?");
}