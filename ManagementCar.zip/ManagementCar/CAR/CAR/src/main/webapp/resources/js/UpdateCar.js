function resetAll(){
	document.getElementsByTagName('form')[0].reset();
}