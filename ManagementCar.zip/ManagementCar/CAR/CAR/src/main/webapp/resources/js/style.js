function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

function myFunctionCar() {
  document.getElementById("myDropdownCar").classList.toggle("showCar");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtnCar')) {
    var dropdowns = document.getElementsByClassName("dropdown-contentCar");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('showCar')) {
        openDropdown.classList.remove('showCar');
      }
    }
  }
}

function myFunctionOffice() {
  document.getElementById("myDropdownOffice").classList.toggle("showOffice");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtnOffice')) {
    var dropdowns = document.getElementsByClassName("dropdown-contentOffice");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('showOffice')) {
        openDropdown.classList.remove('showOffice');
      }
    }
  }
}

function myFunctionParking() {
  document.getElementById("myDropdownParking").classList.toggle("showParking");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtnParking')) {
    var dropdowns = document.getElementsByClassName("dropdown-contentParking");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('showParking')) {
        openDropdown.classList.remove('showParking');
      }
    }
  }
}

function myFunctionTrip() {
  document.getElementById("myDropdownTrip").classList.toggle("showTrip");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtnTrip')) {
    var dropdowns = document.getElementsByClassName("dropdown-contentTrip");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('showTrip')) {
        openDropdown.classList.remove('showTrip');
      }
    }
  }
}
function myFunctionTicket() {
  document.getElementById("myDropdownTicket").classList.toggle("showTicket");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtnTicket')) {
    var dropdowns = document.getElementsByClassName("dropdown-contentTicket");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('showTicket')) {
        openDropdown.classList.remove('showTicket');
      }
    }
  }
}

