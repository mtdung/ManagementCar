function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

window.onclick = function (event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}

function myFunctionCar() {
    document.getElementById("myDropdownCar").classList.toggle("showCar");
}

window.onclick = function (event) {
    if (!event.target.matches('.dropbtnCar')) {
        var dropdowns = document.getElementsByClassName("dropdown-contentCar");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('showCar')) {
                openDropdown.classList.remove('showCar');
            }
        }
    }
}

function myFunctionOffice() {
    document.getElementById("myDropdownOffice").classList.toggle("showOffice");
}

window.onclick = function (event) {
    if (!event.target.matches('.dropbtnOffice')) {
        var dropdowns = document.getElementsByClassName("dropdown-contentOffice");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('showOffice')) {
                openDropdown.classList.remove('showOffice');
            }
        }
    }
}

function myFunctionParking() {
    document.getElementById("myDropdownParking").classList.toggle("showParking");
}

window.onclick = function (event) {
    if (!event.target.matches('.dropbtnParking')) {
        var dropdowns = document.getElementsByClassName("dropdown-contentParking");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('showParking')) {
                openDropdown.classList.remove('showParking');
            }
        }
    }
}

function myFunctionTrip() {
    document.getElementById("myDropdownTrip").classList.toggle("showTrip");
}

window.onclick = function (event) {
    if (!event.target.matches('.dropbtnTrip')) {
        var dropdowns = document.getElementsByClassName("dropdown-contentTrip");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('showTrip')) {
                openDropdown.classList.remove('showTrip');
            }
        }
    }
}
function myFunctionTicket() {
    document.getElementById("myDropdownTicket").classList.toggle("showTicket");
}

window.onclick = function (event) {
    if (!event.target.matches('.dropbtnTicket')) {
        var dropdowns = document.getElementsByClassName("dropdown-contentTicket");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('showTicket')) {
                openDropdown.classList.remove('showTicket');
            }
        }
    }
}

//====================================================================

function clearAll() {
    document.getElementById("office_name").value = "";
    document.getElementById("phone").value = "";
    document.getElementById("price").value = "";
    document.getElementById("fromdate").value = "";
    document.getElementById("todate").value = "";
	document.getElementById("alert").innerHTML = "";
	document.getElementById("noti").innerHTML = "";
	document.getElementById("office_name").style.borderColor = "gray";
    document.getElementById("phone").style.borderColor = "gray";
    document.getElementById("price").style.borderColor = "gray";
    document.getElementById("fromdate").style.borderColor = "gray";
    document.getElementById("todate").style.borderColor = "gray";
}

function checkName(name) {
    if (name.length === 0 || name.length > 50) {
        return false;
    }
    return true;
}

function checkPhone(phone) {
    if (phone.length === 0 || phone.length > 11) {
        return false;
    }
    let isNum = /^\d+$/.test(phone);
    return isNum;
}

function checkPrice(price) {
    if (price.length === 0 || price.length > 20) {
        return false;
    }
    let isNum = /^\d+$/.test(price);
    return isNum;
}

function checkDateFormat(date) {
    var date_format = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/;
    return date_format.test(date);
}

function checkDateLogic(fromdate, todate) {
    var date1 = new Date(fromdate);
    var date2 = new Date(todate);
	console.log(date1);
	console.log(date2);
    if (date1 < date2) {
        return true;
    } else {
        return false;
    }
}

function validateAddBook(){
	var office_name = document.getElementById("office_name").value;
    var phone = document.getElementById("phone").value;
    var price= document.getElementById("price").value;
    var fromdate = document.getElementById("fromdate").value;
    var todate = document.getElementById("todate").value;
	var isValid = true;
	if(!checkDateFormat(fromdate)){
		isValid = false;
		document.getElementById("fromdate").style.borderColor="red";
	} else {
		document.getElementById("fromdate").style.borderColor="black";
	}
	if(!checkDateFormat(todate)){
		isValid = false;
		document.getElementById("todate").style.borderColor="red";
	} else {
		document.getElementById("todate").style.borderColor="black";
	}
	if(!checkName(office_name)){
		isValid = false;
		document.getElementById("office_name").style.borderColor="red";
	} else {
		document.getElementById("office_name").style.borderColor="black";
	}
	if(!checkPhone(phone)){
		isValid = false;
		document.getElementById("phone").style.borderColor="red";
	} else {
		document.getElementById("phone").style.borderColor="black";
	}
	if(!checkPrice(price)){
		isValid = false;
		document.getElementById("price").style.borderColor="red";
	} else {
		document.getElementById("price").style.borderColor="black";
	}
	if(checkDateFormat(fromdate) && checkDateFormat(todate) && (!checkDateLogic(fromdate, todate))){
		isValid = false;
		document.getElementById("fromdate").style.borderColor="red";
		document.getElementById("todate").style.borderColor="red";
	} 
	if(!isValid){
		document.getElementById("alert").innerHTML = "please check your fields";
	} else {
		document.getElementById("alert").innerHTML = "";
	}
	return isValid;
}

