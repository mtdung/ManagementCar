
// Parking
function validateParking() {
	var parkingName = document.getElementById("parkingName").value;
	var area = document.getElementById("area").value;
	var priceParking = document.getElementById("priceParking").value;
	var isValid = true;
	if (parkingName.length > 50 || parkingName.length == 0) {
		isValid = false;
		document.getElementById("parkingName").style.borderColor = "red";
	} else {
		document.getElementById("parkingName").style.borderColor = "gray";
	}
	if(area.length == 0 || area.length > 50 || isNaN(area)){
		isValid = false;
		document.getElementById("area").style.borderColor = "red";
	} else {
		document.getElementById("area").style.borderColor = "gray";
	}

	if(priceParking.length == 0 || priceParking.length > 10 || isNaN(priceParking)){
		isValid = false;
		document.getElementById("priceParking").style.borderColor = "red";
	} else {
		document.getElementById("priceParking").style.borderColor = "gray";
	}
	if(!isValid){
		document.getElementById("alert").innerHTML = "Please check your field(s)";
	}
	else{
		document.getElementById("alert").innerHTML = "";
	}
	return isValid;
}


function deleted(id) {
	var option = confirm('Are you sure to delete');
	if (option === true) {
		window.location.href = 'DeleteController?id=' + id;
	}
}

function clearAll() {
	document.getElementsByTagName('form')[0].reset();
	document.getElementById("alert").innerHTML = "";
	document.getElementById("generalNoti").innerHTML = "";
	document.getElementById("parkingName").style.borderColor = "gray";
	document.getElementById("area").style.borderColor = "gray";
	document.getElementById("priceParking").style.borderColor = "gray";
}
