function clearAll(){
	document.getElementsByTagName('form')[0].reset();
	document.getElementById("license").style.border = "none";
	document.getElementById("type").style.borderColor = "gray";
	document.getElementById("color").style.borderColor = "gray";
	document.getElementById("alert").innerHTML = "";
}

function validateForm(){
	var license = document.getElementById("license").value;
	var type = document.getElementById("type").value;
	var color = document.getElementById("color").value;
	var isValid = true;
	if(license.length <= 0 || license.length > 50){
		isValid = false;
		document.getElementById("license").style.borderColor = "red";
	}
	else{
		document.getElementById("license").style.borderColor = "gray";
	}
	if(type.length <= 0 || type.length > 10){
		isValid = false;
		document.getElementById("type").style.borderColor = "red";
	}
	else{
		document.getElementById("type").style.borderColor = "gray";
	}
	if(color.length <= 0 || color.length > 10){
		isValid = false;
		document.getElementById("color").style.borderColor = "red";
	}
	else{
		document.getElementById("color").style.borderColor = "gray";
	}
	if(!isValid){
		document.getElementById("alert").innerHTML = "Please check your fields!";
	}
	else{
		document.getElementById("alert").innerHTML = "";
	}
	return isValid;
}