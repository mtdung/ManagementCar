function validateForm1() {
	document.getElementById("generalNoti").innerHTML = "";
	document.getElementById("generalAlert").innerHTML = "";
	try {
		var destination = document.getElementById("destination").value;
		var time = document.getElementById("departureTime").value;
		var date = document.getElementById("departureDate").value;
		var driver = document.getElementById("driver").value;
		var carType = document.getElementById("carType").value;
		var maxTicketNumber = document.getElementById("maxTicketNumber").value;
		var bookedTicketNumber = document.getElementById("bookedTicketNumber").value;
		var isValid = true;
		if (!validateDate(date)) {
			document.getElementById("departureDate").style.border = "1px solid red";
			isValid = false;
		}
		else {
			document.getElementById("departureDate").style.border = "1px solid gray";
		}
		if (!validateTime(time)) {
			isValid = false;
		}
		if (carType.length == 0 || carType.length > 50) {
			document.getElementById("carType").style.border = "1px solid red";
			isValid = false;
		}
		else {
			document.getElementById("carType").style.border = "1px solid gray";
		}
		if (driver == null || driver.length == 0 || driver.length > 50) {
			document.getElementById("driver").style.border = "1px solid red";
			isValid = false;
		}
		else {
			document.getElementById("driver").style.border = "1px solid gray";
		}
		if (destination == null || destination.length == 0 || destination.length > 50) {
			document.getElementById("destination").style.border = "1px solid red";
			isValid = false;
		}
		else {
			document.getElementById("destination").style.border = "1px solid gray";
		}
		if (isNaN(maxTicketNumber) || maxTicketNumber <= 0 || maxTicketNumber < bookedTicketNumber) {
			document.getElementById("maxTicketNumber").style.border = "1px solid red";
			isValid = false;
		}
		else {
			document.getElementById("maxTicketNumber").style.border = "1px solid gray";
		}
		if (!isValid) {
			document.getElementById("generalAlert").innerHTML = "Please check the red marked field(s) above!";
		}
		return isValid;
	}
	catch (error) {
		document.getElementById("generalAlert").innerHTML = "Error occured while validating the form!";
		return false;
	}

}

function validateDate(date) {
	var regex = /(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$/;
	return regex.test(date);

}

function validateTime(time) {
	var isValid = true;
	try {
		var time_regex = /^([0]?[0-9]|1[0-1]):([0-5][0-9]) (AM|PM)?$/;
		if (!time.match(time_regex)) {
			document.getElementById("departureTime").style.border = "1px solid red";
			isValid = false;
		}
		else {
			document.getElementById("departureTime").style.border = "1px solid gray";
		}
		return isValid;
	} catch (error) {
		console.log(error)
		return false;
	}
}

function clearAll() {
	document.getElementsByTagName('form')[0].reset();
	document.getElementById("departureDate").style.border = "1px solid gray";
	document.getElementById("departureTime").style.border = "1px solid gray";
	document.getElementById("destination").style.border = "1px solid gray";
	document.getElementById("driver").style.border = "1px solid gray";
	document.getElementById("carType").style.border = "1px solid gray";
	document.getElementById("maxTicketNumber").style.border = "1px solid gray";
	document.getElementById("generalAlert").innerHTML = "";
}