function clearAll() {
	try {
		document.getElementById("customer").value = "";
		document.getElementById("bookingTime").value = "";
		document.getElementById("generalAlert").innerHTML = "";
		document.getElementById("tripListAlert").innerHTML = "";
		document.getElementById("carListAlert").innerHTML = "";
		document.getElementById("generalNoti").innerHTML = "";
	} catch (error) {
		document.getElementById("generalAlert").innerHTML = "Error when reseting!";
	}
}

function validateForm(){
	var customer = document.getElementById("customer").value;
	var trip = document.getElementById("trip").value;
	var licensePlate = document.getElementById("licensePlate").value;
	var isValid = true;
	if(customer.length == 0){
		isValid = false;
		document.getElementById("customer").style.borderColor = "red";
	}
	else{
		document.getElementById("customer").style.borderColor = "gray";
	}
	if(trip.length == 0){
		isValid = false;
		document.getElementById("trip").style.borderColor = "red";
	}
	else{
		document.getElementById("trip").style.borderColor = "gray";
	}
	if(licensePlate.length == 0){
		isValid = false;
		document.getElementById("licensePlate").style.borderColor = "red";
	}
	else{
		document.getElementById("licensePlate").style.borderColor = "gray";
	}
	console.log(bookingTime.length);
	if(!isValid){
		document.getElementById("generalAlert").innerHTML = "Please check your field(s)!";
	}
	return isValid;
}