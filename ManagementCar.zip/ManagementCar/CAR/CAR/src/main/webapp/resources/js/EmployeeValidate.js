function clearAll() {
	document.getElementById("name").value = "";
	document.getElementById("phone").value = "";
	document.getElementById("dateOfBirth").value = "";
	document.getElementById("address").value = "";
	document.getElementById("email").value = "";
	document.getElementById("account").value = "";
	document.getElementById("password").value = "";
	document.getElementById("alert").innerHTML = "";
	document.getElementById("noti").innerHTML = "";
	document.getElementById("name").style.borderColor = "gray";
	document.getElementById("phone").style.borderColor = "gray";
	document.getElementById("dateOfBirth").style.borderColor = "gray";
	document.getElementById("address").style.borderColor = "gray";
	document.getElementById("email").style.borderColor = "gray";
	document.getElementById("account").style.borderColor = "gray";
	document.getElementById("password").style.borderColor = "gray";
}

function validateForm() {
	var name = document.getElementById("name").value;
	var phone = document.getElementById("phone").value;
	var dateOfBirth = document.getElementById("dateOfBirth").value;
	var address = document.getElementById("address").value;
	var email = document.getElementById("email").value;
	var account = document.getElementById("account").value;
	var password = document.getElementById("password").value;
	var isValid = true;
	if (!checkStringLength(name, 50)) {
		isValid = false;
		document.getElementById("name").style.borderColor = "red";
	}
	else {
		document.getElementById("name").style.borderColor = "gray";
	}
	if (!checkPhone(phone)) {
		isValid = false;
		document.getElementById("phone").style.borderColor = "red";
	}
	else {
		document.getElementById("phone").style.borderColor = "gray";
	}
	if (!checkDateFormat(dateOfBirth)) {
		isValid = false;
		document.getElementById("dateOfBirth").style.borderColor = "red";
	}
	else {
		document.getElementById("dateOfBirth").style.borderColor = "gray";
	}
	if (!checkStringLength(address, 50)) {
		isValid = false;
		document.getElementById("address").style.borderColor = "red";
	}
	else {
		document.getElementById("address").style.borderColor = "gray";
	}
	if (!checkStringLength(email, 50)) {
		isValid = false;
		document.getElementById("email").style.borderColor = "red";
	}
	else {
		document.getElementById("email").style.borderColor = "gray";
	}
	if (!checkStringLength(account, 50)) {
		isValid = false;
		document.getElementById("account").style.borderColor = "red";
	}
	else {
		document.getElementById("account").style.borderColor = "gray";
	}
	if (!checkStringLength(password, 100)) {
		isValid = false;
		document.getElementById("password").style.borderColor = "red";
	}
	else {
		document.getElementById("password").style.borderColor = "gray";
	}
	if(!isValid){
		document.getElementById("alert").innerHTML = "Please check your fields";
	} else {
		document.getElementById("alert").innerHTML = "";
	}
	return isValid;
}

function checkPhone(phone) {
	if (phone.length === 0 || phone.length > 11) {
		return false;
	}
	let isNum = /^\d+$/.test(phone);
	return isNum;
}

function checkDateFormat(date) {
	var date_format2 = /^(19|20)\d{2}\/(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])$/; 
	return date_format2.test(date);
}

function checkStringLength(selectedString, length) {
	return !(selectedString.length <= 0 || selectedString.length > length);
}