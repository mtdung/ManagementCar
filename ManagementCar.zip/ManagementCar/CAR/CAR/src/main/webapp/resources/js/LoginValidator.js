function validate(){
    //check account
    var isValid = true;
    var account = document.getElementById("account").value;
    if(account.length == 0){
        document.getElementById("accountAlert").innerHTML = "Please enter your account!";
        isValid = false;
    }
    else if(account.length > 50){
        document.getElementById("accountAlert").innerHTML = "Your account must be less than 50 characters!";
        isValid = false;
    }
    else{
        document.getElementById("accountAlert").innerHTML = "";
    }
    //check password
    var password = document.getElementById("password").value;
    if(password.length == 0){
        document.getElementById("passwordAlert").innerHTML = "Please enter your password!";
        isValid = false;
    }
    else{
        document.getElementById("passwordAlert").innerHTML = "";
    }
    return isValid;
}
