package fa.training.dao;

import java.sql.SQLException;
import java.util.List;

import fa.training.model.Parking;

public interface ParkingLotDAO {
	List<Parking> getListParking() throws SQLException; 
	
	List<Parking> getAll(int index, int pageSize) throws SQLException;
	
	List<Parking> getAllBy(String randomString, String search, int index, int pageSize) throws SQLException;
	
	boolean delete(String id) throws SQLException;
	
	boolean edit(String name, String place, String area, String price, String status, String id) throws SQLException;
	
	int count() throws SQLException;
	
	int countSearch(String randomString, String search) throws SQLException;

	boolean add(String name, String place, String area, String price, String status) throws SQLException;
	
	List<Parking> getParkingId(String id) throws SQLException;
}
