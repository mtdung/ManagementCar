package fa.training.model;

import java.sql.Date;
import java.sql.Time;

public class TicketDTO {
	private long ticket_id;
	private String trip_destination;
	private String license_plate;
	private String customer;
	private Time booking_time;
	private Date departure_date;
	public TicketDTO() {
		super();
	}

	public TicketDTO(long ticket_id, String trip_destination, String license_plate, String customer,
			Time booking_time, Date departure_date) {
		super();
		this.ticket_id = ticket_id;
		this.trip_destination = trip_destination;
		this.license_plate = license_plate;
		this.customer = customer;
		this.booking_time = booking_time;
		this.departure_date = departure_date;
	}

	public long getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(long ticket_id) {
		this.ticket_id = ticket_id;
	}

	public String getTrip_destination() {
		return trip_destination;
	}

	public void setTrip_destination(String trip_destination) {
		this.trip_destination = trip_destination;
	}

	public String getLicense_plate() {
		return license_plate;
	}

	public void setLicense_plate(String license_plate) {
		this.license_plate = license_plate;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public Time getBooking_time() {
		return booking_time;
	}

	public void setBooking_time(Time booking_time) {
		this.booking_time = booking_time;
	}

	public Date getDeparture_date() {
		return departure_date;
	}

	public void setDeparture_date(Date departure_date) {
		this.departure_date = departure_date;
	}
	
	public String getTime() {
		if(getBooking_time() == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		int hour = getBooking_time().toLocalTime().getHour();
		int minute = getBooking_time().toLocalTime().getMinute();
		if(hour < 10) {
			sb.append('0');
		}
		sb.append(hour);
		sb.append(':');
		if(minute < 10) {
			sb.append('0');
		}
		sb.append(minute);
		return sb.toString();
	}
}
