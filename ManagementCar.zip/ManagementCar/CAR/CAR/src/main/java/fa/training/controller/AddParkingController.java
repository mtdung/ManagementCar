package fa.training.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.ParkingLotDAO;
import fa.training.dao.impl.ParkingLotDAOImpl;
import fa.training.model.Employee;
@WebServlet("/AddController")
public class AddParkingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddParkingController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/AddParking.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String parkingName = request.getParameter("parkingName");
		String place = request.getParameter("place");
		String area = request.getParameter("area");
		String price = request.getParameter("price");
		ParkingLotDAO dao = new ParkingLotDAOImpl();
		try {
			dao.add(parkingName, place, area, price, "Blank");
			request.setAttribute("success", true);
			request.getRequestDispatcher("views/AddParking.jsp").forward(request, response);
		} catch (SQLException e) {
			request.setAttribute("errorSQL", true);
			request.getRequestDispatcher("views/AddParking.jsp").forward(request, response);
			e.printStackTrace();
		}
	}
}
