package fa.training.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import fa.training.dao.ParkingLotDAO;
import fa.training.model.Parking;
import fa.training.utils.DBConnection;
import fa.training.utils.SQLCommand;

public class ParkingLotDAOImpl implements ParkingLotDAO{
	
	private Connection conn;
	private PreparedStatement pre;
	private ResultSet rs;
	
	@Override
	public List<Parking> getListParking() throws SQLException {
		List<Parking> listP = new ArrayList<>();
		try {
			conn = new DBConnection().getConnection();
			pre = conn.prepareStatement(SQLCommand.getParkingLot);
			rs = pre.executeQuery();
			while(rs.next()) {
				listP.add(new Parking(rs.getInt("park_id"), rs.getString("name_park")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return listP;
	}
	
	public List<Parking> getAll(int index, int pageSize) throws SQLException {
		List<Parking> parkings = new ArrayList<Parking>();
		Parking parking = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			pre = conn.prepareStatement(SQLCommand.GET_ALL);
			pre.setInt(1, index);
			pre.setInt(2, pageSize);
			pre.setInt(3, pageSize);
			pre.setInt(4, index);
			pre.setInt(5, pageSize);
			rs = pre.executeQuery();
			while (rs.next()) {
				parking = new Parking();
				parking.setPark_id(rs.getLong("park_id"));
				parking.setName_park(rs.getString("name_park"));
				parking.setPlace(rs.getString("place"));
				parking.setArea(rs.getLong("area"));
				parking.setPrice(rs.getLong("price"));
				parking.setStatus_park(rs.getInt("status_park"));
				parkings.add(parking);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return parkings;
	}

	public List<Parking> getAllBy(String randomString, String search, int index, int pageSize) throws SQLException {
		List<Parking> parkings = new ArrayList<Parking>();
		Parking parking = null;
		if (randomString.equals("status_park") && search.equalsIgnoreCase("Blank")) {
			search = "0";
		} else if (randomString.equals("status_park") && search.equalsIgnoreCase("UnBlank")) {
			search = "1";
		}
		try {
			conn = DBConnection.getInstance().getConnection();
			String query = SQLCommand.GET_ALL_BY.replace(SQLCommand.randomString, randomString);
			pre = conn.prepareStatement(query);
			pre.setString(1, search);
			pre.setInt(2, index);
			pre.setInt(3, pageSize);
			pre.setInt(4, pageSize);
			pre.setInt(5, index);
			pre.setInt(6, pageSize);
			rs = pre.executeQuery();
			while (rs.next()) {
				parking = new Parking();
				parking.setPark_id(rs.getLong("park_id"));
				parking.setName_park(rs.getString("name_park"));
				parking.setPlace(rs.getString("place"));
				parking.setArea(rs.getLong("area"));
				parking.setPrice(rs.getLong("price"));
				parking.setStatus_park(rs.getInt("status_park"));
				parkings.add(parking);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return parkings;
	}

	public boolean delete(String id) throws SQLException {
		boolean check = false;
		try {
			conn = DBConnection.getInstance().getConnection();
			pre = conn.prepareStatement(SQLCommand.GET_DELETE);
			pre.setString(1, id);
			pre.setString(2, id);
			pre.setString(3, id);
			check = pre.executeUpdate() == 1;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

		return check;
	}

	public boolean edit(String name, String place, String area, String price, String status, String id)
			throws SQLException {
		boolean check = false;
		if (status.equalsIgnoreCase("Blank")) {
			status = "0";
		} else if (status.equalsIgnoreCase("UnBlank")) {
			status = "1";
		}
		try {
			conn = DBConnection.getInstance().getConnection();
			pre = conn.prepareStatement(SQLCommand.GET_EDIT);
			pre.setString(1, name);
			pre.setString(2, place);
			pre.setString(3, area);
			pre.setString(4, price);
			pre.setString(5, status);
			pre.setString(6, id);
			check = pre.executeUpdate() == 1;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return check;
	}

	public int count() throws SQLException {
		try {
			conn = DBConnection.getInstance().getConnection();
			String query = "select count(*) from PARKINGLOT";
			pre = conn.prepareStatement(query);
			rs = pre.executeQuery();
			int count = 0;
			while (rs.next()) {
				count = rs.getInt(1);
			}
			return count;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public int countSearch(String randomString, String search) throws SQLException {
		if (randomString.equals("status_park") && search.equalsIgnoreCase("Blank")) {
			search = "0";
		} else if (randomString.equals("status_park") && search.equalsIgnoreCase("UnBlank")) {
			search = "1";
		}
		try {
			conn = DBConnection.getInstance().getConnection();
			String query = SQLCommand.GET_COUNT_BY.replace(SQLCommand.randomString, randomString);
			pre = conn.prepareStatement(query);
			pre.setString(1, search);
			rs = pre.executeQuery();
			int count = 0;
			while (rs.next()) {
				count = rs.getInt(1);
			}
			return count;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public boolean add(String name, String place, String area, String price, String status)
			throws SQLException {
		boolean check = false;
		if (status.equalsIgnoreCase("Blank")) {
			status = "0";
		} else if (status.equalsIgnoreCase("UnBlank")) {
			status = "1";
		}
		try {
			conn = DBConnection.getInstance().getConnection();
			pre = conn.prepareStatement(SQLCommand.GET_ADD);
			pre.setString(1, name);
			pre.setString(2, place);
			pre.setString(3, area);
			pre.setString(4, price);
			pre.setString(5, status);
			check = pre.executeUpdate() == 1;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return check;
	}
	
	public List<Parking> getParkingId(String id) throws SQLException {
		List<Parking> parkings = new ArrayList<>();
		Parking parking = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			pre = conn.prepareStatement(SQLCommand.GET_SELECT_PARKING);
			pre.setString(1, id);
			rs = pre.executeQuery();
			while(rs.next()) {
				parking = new Parking();
				parking.setPark_id(rs.getInt("park_id"));
				parking.setName_park(rs.getString("name_park"));
				parking.setPlace(rs.getString("place"));
				parking.setArea(rs.getLong("area"));
				parking.setPrice(rs.getLong("price"));
				parking.setStatus_park(rs.getInt("status_park"));
				parkings.add(parking);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return parkings;
	}

}
