package fa.training.controller;

import java.io.IOException;
import java.sql.Time;
import java.time.LocalTime;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import fa.training.dao.TicketDAO;
import fa.training.dao.impl.*;
import fa.training.dao.TripDAO;
import fa.training.model.Employee;
import fa.training.model.Trip;

/**
 * Servlet implementation class AddTicketServlet
 */
@WebServlet("/AddTicketServlet")
public class AddTicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddTicketServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			try {
				TripDAO tripDAO = new TripDAOImpl();
				List<Trip> tripList = tripDAO.getAllTrips();
				if (tripList.isEmpty()) {
					request.setAttribute("tripListAlert", "There's no trip to add ticket to!");
				} else {
					session.setAttribute("ticketTripList", tripList);
				}
				TicketDAO ticketDAO = new TicketDAOImpl();
				List<String> carList = ticketDAO.getAllLicensePlates();
				if (carList.isEmpty()) {
					request.setAttribute("carListAlert", "There's no car!");
				} else {
					session.setAttribute("carList", carList);
				}
			} catch (Exception e) {
				request.setAttribute("generalAlert", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/AddTicket.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String customer = request.getParameter("customer");
		String bookingTime = request.getParameter("bookingTime");
		String[] timeParts = bookingTime.split(":");
		Time time = Time.valueOf(LocalTime.of(Integer.parseInt(timeParts[0]), Integer.parseInt(timeParts[1])));
		long trip_id = Long.parseLong(request.getParameter("trip"));
		String licensePlate = request.getParameter("licensePlate");
		try {
			TicketDAO ticketDAO = new TicketDAOImpl();
			boolean isAdded = ticketDAO.addTicket(customer, time, trip_id, licensePlate);
			if(isAdded) {
				request.setAttribute("generalNoti", "Add ticket successful!");
			}
			else {
				request.setAttribute("generalALert", "Add ticket failed!");
			}
		} catch (Exception e) {
			request.setAttribute("generalAlert", "Error occured!");
		} finally {
			request.getRequestDispatcher("views/AddTicket.jsp").forward(request, response);
		}
		
	}

}
