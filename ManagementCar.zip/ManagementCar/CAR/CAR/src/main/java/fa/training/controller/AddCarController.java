package fa.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.CarDAO;
import fa.training.dao.ParkingLotDAO;
import fa.training.dao.impl.CarDAOImpl;
import fa.training.dao.impl.ParkingLotDAOImpl;
import fa.training.model.Employee;
import fa.training.model.Parking;

/**
 * Servlet implementation class AddCarController
 */
@WebServlet("/addcar")
public class AddCarController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddCarController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	ParkingLotDAO parkDAO = new ParkingLotDAOImpl();
	CarDAO dao = new CarDAOImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// loginStatus
		// 0 - not logged in
		// 1 - employee
		// 2 - admin
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			try {
				List<Parking> listP = parkDAO.getListParking();
				request.setAttribute("listP", listP);
			} catch (SQLException e) {
				request.setAttribute("mess", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String lic = request.getParameter("license");
		String type = request.getParameter("type");
		String color = request.getParameter("color");
		String company = request.getParameter("company");
		String park_id = request.getParameter("park_id");
		int company_number = 0;
		if (company.equals("Company 1")) {
			company_number = 1;
		} else if (company.equals("Company 2")) {
			company_number = 2;
		} else if (company.equals("Company 3")) {
			company_number = 3;
		} else {
			company_number = 4;
		}
		try {
			List<Parking> listP = parkDAO.getListParking();
			boolean check = dao.addCar(lic, type, color, company, park_id);
			if (check == true) {
				request.setAttribute("listP", listP);
				request.setAttribute("mess", "Add Car sucessfull!");
				request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);
			} else {
				request.setAttribute("type", type);
				request.setAttribute("color", color);
				request.setAttribute("listP", listP);
				request.setAttribute("park_id", park_id);
				request.setAttribute("company", company_number);
				request.setAttribute("mess", "License_plate existed!");
				request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);
			}
//			if(!lic.equals("") && !type.equals("") && !color.equals("") && !company.equals("") && !park_id.equals("")) {
//				if(lic.length() > 10) {
//					request.setAttribute("type", type);
//					request.setAttribute("color", color);
//					request.setAttribute("listP", listP);
//					request.setAttribute("mess", "Please enter license_plate max 10 characters!");
//					request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);
//				}else if(type.length() > 10) {
//					request.setAttribute("license", lic);
//					request.setAttribute("color", color);
//					request.setAttribute("listP", listP);
//					request.setAttribute("mess", "Please enter type max 10 characters!");
//					request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);
//				}else if(color.length() > 10) {
//					request.setAttribute("license", lic);
//					request.setAttribute("type", type);
//					request.setAttribute("listP", listP);
//					request.setAttribute("mess", "Please enter color max 10 characters!");
//					request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);
//				}else {

//				}
//			}else {
//				request.setAttribute("license", lic);
//				request.setAttribute("type", type);
//				request.setAttribute("color", color);
//				request.setAttribute("listP", listP);
//				request.setAttribute("mess", "Please fill all required fields!");
//				request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("mess", "Add Car unsucessfull!");
			request.getRequestDispatcher("views/AddCar.jsp").forward(request, response);
		}
	}

}
