package fa.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.ParkingLotDAO;
import fa.training.dao.impl.ParkingLotDAOImpl;
import fa.training.model.Employee;
import fa.training.model.Parking;
import fa.training.utils.Constants;

@WebServlet(name = "listParking", urlPatterns = { "/listParking" })
public class ParkingLotListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ParkingLotListController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			String nameCol = request.getParameter("nameCol");
			String search = request.getParameter("search");
			ParkingLotDAO dao = new ParkingLotDAOImpl();
			boolean pre = false;
			boolean next = false;
			try {
				String pageIndex = request.getParameter("index");
				if (pageIndex == null || pageIndex.equals("1")) {
					pre = true;
					pageIndex = "1";
				}
				int index = Integer.parseInt(pageIndex);
				int total;
				if (search == null || search == "") {
					total = dao.count();
				} else {
					total = dao.countSearch(nameCol, search);
				}
				int maxPage = total / Constants.PAGE_SIZE;
				if (total % Constants.PAGE_SIZE != 0) {
					maxPage++;
				}
				if (index == maxPage) {
					next = true;
				}
				List<Parking> list;
				if (search == null || search == "") {
					list = dao.getAll(index, Constants.PAGE_SIZE);
				} else {
					list = dao.getAllBy(nameCol, search, index, Constants.PAGE_SIZE);
				}
				request.setAttribute("search", search);
				request.setAttribute("nameColumn", nameCol);
				request.setAttribute("maxPage", maxPage);
				request.setAttribute("list", list);
				request.setAttribute("index", index);
				request.setAttribute("pre", pre);
				request.setAttribute("next", next);
				if (list.size() == 0) {
					request.setAttribute("generalAlert", "Not found any parking lot!");
				}
			} catch (SQLException e) {
				request.setAttribute("generalAlert", "Error occured!");
				e.printStackTrace();
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/ParkingLotList.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
			
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
}
