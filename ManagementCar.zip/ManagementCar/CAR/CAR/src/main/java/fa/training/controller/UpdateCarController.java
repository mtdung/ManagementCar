package fa.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.CarDAO;
import fa.training.dao.ParkingLotDAO;
import fa.training.dao.impl.CarDAOImpl;
import fa.training.dao.impl.ParkingLotDAOImpl;
import fa.training.model.Car;
import fa.training.model.Employee;
import fa.training.model.Parking;

/**
 * Servlet implementation class UpdateCarController
 */
@WebServlet("/updatecar")
public class UpdateCarController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateCarController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    ParkingLotDAO parkDAO = new ParkingLotDAOImpl();
	CarDAO dao = new CarDAOImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			String lic = request.getParameter("license");
			try {
				Car c = dao.getCarbyLicense(lic);
				List<Parking> listP = parkDAO.getListParking();
				request.setAttribute("license", c.getLicense());
				request.setAttribute("type", c.getType());
				request.setAttribute("color", c.getColor());
				if(c.getCompany().equals("Company 1")) {
					request.setAttribute("company", 1);
				}else if(c.getCompany().equals("Company 2")) {
					request.setAttribute("company", 2);
				}else if(c.getCompany().equals("Company 3")) {
					request.setAttribute("company", 3);
				}else {
					request.setAttribute("company", 4);
				}
				request.setAttribute("park_id", c.getPark_id());
				request.setAttribute("listP", listP);
			} catch (SQLException e) {
				request.setAttribute("generalAlert", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/UpdateCar.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			String lic = request.getParameter("license");
			String type = request.getParameter("type");
			String color = request.getParameter("color");
			String company = request.getParameter("company");
			long park_id = Long.parseLong(request.getParameter("park_id"));
			boolean check = dao.updateCar(lic, type, color, company, park_id);
			if(check == true) {
				request.setAttribute("generalNoti", "Update successful!");
			}
			else {
				request.setAttribute("generalAlert", "Update failed!");
			} 
		} catch (SQLException e) {
			request.setAttribute("generalNoti", "Error occured!");
		} finally {
			request.getRequestDispatcher("listcar").forward(request, response);
		}
	}

}
