package fa.training.model;

import java.sql.Time;

public class Ticket {
	private long ticket_id;
	private Time booking_time;
	private String customer_name;
	private String license_plate;
	private long trip_id;

	public Ticket() {
		super();
	}

	public Ticket(long ticket_id, Time booking_time, String customer_name, String license_plate, long trip_id) {
		super();
		this.ticket_id = ticket_id;
		this.booking_time = booking_time;
		this.customer_name = customer_name;
		this.license_plate = license_plate;
		this.trip_id = trip_id;
	}

	public long getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(long ticket_id) {
		this.ticket_id = ticket_id;
	}

	public Time getBooking_time() {
		return booking_time;
	}

	public void setBooking_time(Time booking_time) {
		this.booking_time = booking_time;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getLicense_plate() {
		return license_plate;
	}

	public void setLicense_plate(String license_plate) {
		this.license_plate = license_plate;
	}

	public long getTrip_id() {
		return trip_id;
	}

	public void setTrip_id(long trip_id) {
		this.trip_id = trip_id;
	}
}
