package fa.training.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.TripDAO;
import fa.training.dao.impl.*;
import fa.training.model.Employee;
import fa.training.model.Trip;

/**
 * Servlet implementation class EditTripServlet
 */
@WebServlet("/EditTripServlet")
public class EditTripServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditTripServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			try {
				int trip_id = Integer.parseInt(request.getParameter("trip_id"));
				TripDAO tripDAO = new TripDAOImpl();
				Trip trip = tripDAO.getTripByID(trip_id);
				if (trip == null) {
					request.setAttribute("generalAlert", "No trips found!");
				} else {
					request.setAttribute("trip", trip);
				}
			} catch (NullPointerException e) {
				request.setAttribute("generalAlert", "Trip id is missing. No trip loaded!");
			} catch (NumberFormatException e) {
				request.setAttribute("generalAlert", "Trip id must be a number!");
			} catch (Exception e) {
				request.setAttribute("generalAlert", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/EditTrip.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String destination = request.getParameter("destination");
			String driver = request.getParameter("driver");
			String carType = request.getParameter("carType");
			int bookedTicket = Integer.parseInt(request.getParameter("bookedTicketNumber"));
			int maxTicket = Integer.parseInt(request.getParameter("maxTicketNumber"));
			String dateString = request.getParameter("departureDate");
			String timeString = request.getParameter("departureTime");
			int trip_id = Integer.parseInt(request.getParameter("trip_id"));
			Timestamp t = Timestamp.valueOf(LocalDateTime.of(Integer.parseInt(dateString.substring(6, 10)),
					Integer.parseInt(dateString.substring(3, 5)), Integer.parseInt(dateString.substring(0, 2)),
					Integer.parseInt(timeString.substring(0, 2)), Integer.parseInt(timeString.substring(3, 5))));
			if (timeString.substring(6).equals("PM")) {
				t = Timestamp.valueOf(t.toLocalDateTime().plusHours(12));
			}
			TripDAO tripDAO = new TripDAOImpl();
			Trip currentTrip = new Trip();
			currentTrip.setTrip_id(trip_id);
			currentTrip.setDestination(destination);
			currentTrip.setDeparture_date(t);
			currentTrip.setDriver(driver);
			currentTrip.setSeat_type(carType);
			currentTrip.setBooked_ticket(bookedTicket);
			currentTrip.setMax_ticket(maxTicket);
			if(tripDAO.editTrip(currentTrip)) {
				request.setAttribute("generalNoti", "Edit successful!");
				request.setAttribute("trip", currentTrip);
			}
			else {
				request.setAttribute("generalAlert", "Edit failed!");
				request.setAttribute("trip", tripDAO.getTripByID(trip_id));
			}
		} catch (Exception e) {
			request.setAttribute("generalAlert", "Error occured!");
		}
		request.getRequestDispatcher("views/EditTrip.jsp").forward(request, response);

	}

}
