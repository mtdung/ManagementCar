package fa.training.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import fa.training.dao.TicketDAO;
import fa.training.model.TicketDTO;
import fa.training.utils.Constants;
import fa.training.utils.DBConnection;
import fa.training.utils.SQLCommand;

public class TicketDAOImpl implements TicketDAO {

	private Connection con;
	private PreparedStatement stm;
	private ResultSet rs;

	@Override
	public List<String> getAllLicensePlates() throws SQLException {
		List<String> allCars = new ArrayList<>();
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_ALL_LICENSE_PLATES);
			rs = stm.executeQuery();
			while (rs.next()) {
				allCars.add(rs.getString("license_plate"));
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return allCars;
	}

	@Override
	public boolean addTicket(String cus_name, Time booking_time, long trip_id, String license_plate)
			throws SQLException {
		if (cus_name == null || cus_name.isEmpty() || booking_time == null || license_plate == null
				|| license_plate.isEmpty()) {
			return false;
		}
		boolean isAdded = false;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.ADD_TICKET);
			stm.setString(1, cus_name);
			stm.setTime(2, booking_time);
			stm.setLong(3, trip_id);
			stm.setString(4, license_plate);
			isAdded = stm.executeUpdate() > 0;
		} finally {
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return isAdded;
	}

	@Override
	public List<TicketDTO> getLatestTicketDTO(int page) throws SQLException {
		List<TicketDTO> ticketList = new ArrayList<>();
		TicketDTO currentTicket = null;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_LATEST_TICKETDTO);
			stm.setInt(1, Constants.PAGE_SIZE * page - Constants.PAGE_SIZE + 1);
			stm.setInt(2, Constants.PAGE_SIZE * page);
			rs = stm.executeQuery();
			while (rs.next()) {
				currentTicket = new TicketDTO();
				currentTicket.setTicket_id(rs.getLong("ticket_id"));
				currentTicket.setTrip_destination(rs.getString("destination"));
				currentTicket.setLicense_plate(rs.getString("license_plate"));
				currentTicket.setCustomer(rs.getString("cus_name"));
				currentTicket.setBooking_time(rs.getTime("booking_time"));
				currentTicket.setDeparture_date(rs.getDate("depature_date"));
				ticketList.add(currentTicket);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return ticketList;
	}

	@Override
	public int getNumberOfTicketDTOByDate(Date date, String filterBy, String searchedPattern) throws SQLException {
		if (date == null || filterBy == null || filterBy.isEmpty() || searchedPattern == null) {
			return -1;
		}
		int result = 0;
		try {
			boolean isSearchedAll = false;
			con = DBConnection.getInstance().getConnection();
			String sql = SQLCommand.GET_NUMBER_OF_SELECTED_TICKETDTO;
			if (filterBy.equals("All")) {
				sql = sql.replace(SQLCommand.FILTER_PART, "");
				isSearchedAll = true;
			} else {
				sql = sql.replace(SQLCommand.STRING_TO_REPLACE, filterBy);
			}
			stm = con.prepareStatement(sql);
			stm.setDate(1, date);
			if (!isSearchedAll) {
				stm.setString(2, ("%" + searchedPattern + "%"));
			}
			rs = stm.executeQuery();
			while (rs.next()) {
				result++;
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return result;
	}

	@Override
	public List<TicketDTO> searchTicket(int page, Date date, String filterBy, String searchedPattern)
			throws SQLException {
		if (page == 0 || date == null || filterBy == null || filterBy.isEmpty() || searchedPattern == null) {
			return new ArrayList<>();
		}
		List<TicketDTO> ticketList = new ArrayList<>();
		TicketDTO currentTicket = null;
		try {
			boolean isSearchedAll = false;
			con = DBConnection.getInstance().getConnection();
			String sql = SQLCommand.GET_TICKETDTO_BY_DATE_AND_FILTER;
			if (filterBy.equals("All")) {
				sql = sql.replace(SQLCommand.FILTER_PART, "");
				isSearchedAll = true;
			} else {
				sql = sql.replace(SQLCommand.STRING_TO_REPLACE, filterBy);
			}
			stm = con.prepareStatement(sql);
			int indexToPassParam = 1;
			stm.setDate(indexToPassParam, date);
			indexToPassParam++;
			if (!isSearchedAll) {
				stm.setString(indexToPassParam, "%" + searchedPattern + "%");
				indexToPassParam++;
			}
			stm.setInt(indexToPassParam, Constants.PAGE_SIZE * page - Constants.PAGE_SIZE + 1);

			stm.setInt(indexToPassParam + 1, Constants.PAGE_SIZE * page);
			rs = stm.executeQuery();
			while (rs.next()) {
				currentTicket = new TicketDTO();
				currentTicket.setTicket_id(rs.getLong("ticket_id"));
				currentTicket.setTrip_destination(rs.getString("destination"));
				currentTicket.setLicense_plate(rs.getString("license_plate"));
				currentTicket.setCustomer(rs.getString("cus_name"));
				currentTicket.setBooking_time(rs.getTime("booking_time"));
				currentTicket.setDeparture_date(rs.getDate("depature_date"));
				ticketList.add(currentTicket);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return ticketList;
	}

	@Override
	public boolean deleteTicket(long ticket_id) throws SQLException {
		boolean isDeleted = false;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.DELETE_TICKET);
			stm.setLong(1, ticket_id);
			isDeleted = stm.executeUpdate() > 0;
		} finally {
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return isDeleted;
	}
}
