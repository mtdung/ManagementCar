/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fa.training.model;

import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Bau
 */
public class BookOffice {
    int id, price, tripId;
    String name, phoneNumber, place;
    Date startContract, endContract;

    public BookOffice() {
    }

    public BookOffice(int id, int price, int tripId, String name, String phoneNumber, String place, Date startContract, Date endContract) {
        this.id = id;
        this.price = price;
        this.tripId = tripId;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.place = place;
        this.startContract = startContract;
        this.endContract = endContract;
    }
    

    public BookOffice(String price, String tripID, String name, String phone, String place, String fromDate, String toDate) throws ParseException {
        this.price = Integer.parseInt(price);
        this.tripId = Integer.parseInt(tripID);
        this.name = name;
        this.phoneNumber = phone;
        this.place = place;
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy"); 
        this.startContract = (Date) format.parse(fromDate);
        this.endContract = (Date) format.parse(toDate);
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getTripId() {
        return tripId;
    }

    public void setTripId(int tripId) {
        this.tripId = tripId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public Date getStartContract() {
        return startContract;
    }

    public void setStartContract(Date startContract) {
        this.startContract = startContract;
    }

    public Date getEndContract() {
        return endContract;
    }

    public void setEndContract(Date endContract) {
        this.endContract = endContract;
    }

    @Override
    public String toString() {
        return "BookOffice{" + "id=" + id + ", price=" + price + ", tripId=" + tripId + ", name=" + name + ", phoneNumber=" + phoneNumber + ", place=" + place + ", startContract=" + startContract + ", endContract=" + endContract + '}';
    }
    
    
    
    
}
