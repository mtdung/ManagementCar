package fa.training.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;
import fa.training.model.TicketDTO;

public interface TicketDAO {
	List<String> getAllLicensePlates() throws SQLException;
	boolean addTicket(String cus_name, Time booking_time, long trip_id, String license_plate) throws SQLException;
	List<TicketDTO> getLatestTicketDTO(int page) throws SQLException;
	int getNumberOfTicketDTOByDate(Date date, String filterBy, String searchedPattern) throws SQLException;
	List<TicketDTO> searchTicket(int page, Date date, String filterBy, String searchedPattern) throws SQLException;
	boolean deleteTicket(long ticket_id) throws SQLException;
}
