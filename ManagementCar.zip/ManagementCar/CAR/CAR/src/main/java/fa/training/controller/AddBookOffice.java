/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fa.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.impl.BookOfficeDAOImpl;
import fa.training.dao.impl.TripDAOImpl;
import fa.training.model.BookOffice;
import fa.training.model.Employee;
import fa.training.model.Trip;

@WebServlet("/addbookoffice")
public class AddBookOffice extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AddBookOffice() {
		super();
	}

	BookOfficeDAOImpl BDB = new BookOfficeDAOImpl();
	TripDAOImpl TDB = new TripDAOImpl();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			try {
				List<Trip> tripList = TDB.getAllTrips();
				request.setAttribute("listD", tripList);
			} catch (SQLException e) {
				request.setAttribute("generalAlert", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/AddBookingOffice.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			String name = request.getParameter("office_name");
			String phone = request.getParameter("phone");
			String price = request.getParameter("price");
			String place = request.getParameter("place");
			String tripID = request.getParameter("trip");
			String fromDate = request.getParameter("fromdate");
			String toDate = request.getParameter("todate");

			try {
				BookOffice B = new BookOffice(price, tripID, name, phone, place, fromDate, toDate);
				boolean check = BDB.AddBookOffice(B);
				if (check) {
					request.setAttribute("generalNoti", "Add sucessfull!");
				}
				else {
					request.setAttribute("generalAlert", "Add failed!");
				}
				List<Trip> tripList = TDB.getAllTrips();
				request.setAttribute("listD", tripList);
			} catch (Exception ex) {
				request.setAttribute("generalAlert", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/AddBookingOffice.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
		

	}

}
