/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fa.training.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.impl.BookOfficeDAOImpl;
import fa.training.model.BookOfficeDestination;
import fa.training.model.Employee;
/**
 *
 * @author Bau
 */
@WebServlet(name = "SearchBookOffice", urlPatterns = {"/SearchBookOffice"})
public class SearchBookOffice extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	BookOfficeDAOImpl BDB = new BookOfficeDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			try {
				String filter = request.getParameter("filterBy");
				String textSearch = request.getParameter("textSearch");
				int index = 0;
				try {
					index = Integer.parseInt(request.getParameter("index"));
				} catch (Exception e) {
					index = 1;
				}
				int count = BDB.countBookOfficeSearch(filter, textSearch);
				int size = 3;
				int lastPage = count / size;
				if (count % size != 0) {
					lastPage++;
				}
				if(filter.equals("all")) {
					response.sendRedirect(request.getContextPath() + "/viewbookoffice");
					return;
				}else {
					ArrayList<BookOfficeDestination> listB = BDB.getBookOfficeDestinationListSearch(filter, textSearch, index, size);
					if (listB.size() > 0) {
						if(filter.equals("bookoffice_name")) {
							request.setAttribute("select", 1);
						}else if(filter.equals("destination")){
							request.setAttribute("select", 2);
						}
						request.setAttribute("filterBy", filter);
						request.setAttribute("textSearch", textSearch);
						request.setAttribute("index", index);
						request.setAttribute("lastPage", lastPage);
						request.setAttribute("listB", listB);
						request.setAttribute("check", true);
					} else {
						request.setAttribute("mess", "Result Empty!");
					}
				}
			} catch (Exception e) {
				request.setAttribute("mess", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/ViewBookingOffice.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
    }
}
