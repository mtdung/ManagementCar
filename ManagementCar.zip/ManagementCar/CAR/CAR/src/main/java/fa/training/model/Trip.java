package fa.training.model;

import java.sql.Timestamp;

public class Trip {
	private long trip_id;
	private String destination;
	private Timestamp departure_date;
	private String driver;
	private String seat_type;
	private int booked_ticket;
	private int max_ticket;

	public Trip() {
		super();
	}

	public Trip(long trip_id, String destination, Timestamp departure_date, String driver, String seat_type,
			int booked_ticket, int max_ticket) {
		super();
		this.trip_id = trip_id;
		this.destination = destination;
		this.departure_date = departure_date;
		this.driver = driver;
		this.seat_type = seat_type;
		this.booked_ticket = booked_ticket;
		this.max_ticket = max_ticket;
	}

	public long getTrip_id() {
		return trip_id;
	}

	public void setTrip_id(long trip_id) {
		this.trip_id = trip_id;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Timestamp getDeparture_date() {
		return departure_date;
	}

	public void setDeparture_date(Timestamp departure_date) {
		this.departure_date = departure_date;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getSeat_type() {
		return seat_type;
	}

	public void setSeat_type(String seat_type) {
		this.seat_type = seat_type;
	}

	public int getBooked_ticket() {
		return booked_ticket;
	}

	public void setBooked_ticket(int booked_ticket) {
		this.booked_ticket = booked_ticket;
	}

	public int getMax_ticket() {
		return max_ticket;
	}

	public void setMax_ticket(int max_ticket) {
		this.max_ticket = max_ticket;
	}

	public String getTime() {
		if(getDeparture_date() == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		int hour = getDeparture_date().toLocalDateTime().getHour();
		int minute = getDeparture_date().toLocalDateTime().getMinute();
		if(hour < 10) {
			sb.append('0');
		}
		sb.append(hour);
		sb.append(':');
		if(minute < 10) {
			sb.append('0');
		}
		sb.append(minute);
		return sb.toString();
	}
	
	public String getAmOrPMTime() {
		if(getDeparture_date() == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		int hour = getDeparture_date().toLocalDateTime().getHour();
		int minute = getDeparture_date().toLocalDateTime().getMinute();
		String time = hour > 11? "PM": "AM";
		hour = hour % 12;
		if(hour < 10) {
			sb.append('0');
		}
		sb.append(hour);
		sb.append(':');
		if(minute < 10) {
			sb.append('0');
		}
		sb.append(minute);
		sb.append(" ");
		sb.append(time);
		return sb.toString();
	}
	
	public String getDate() {
		if(getDeparture_date() == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		int day = getDeparture_date().toLocalDateTime().getDayOfMonth();
		int month = getDeparture_date().toLocalDateTime().getMonthValue();
		int year = getDeparture_date().toLocalDateTime().getYear();
		if(day < 10) {
			sb.append('0');
		}
		sb.append(day);
		sb.append('/');
		if(month < 10) {
			sb.append('0');
		}
		sb.append(month);
		sb.append('/');
		sb.append(year);
		return sb.toString();
	}
	@Override
	public String toString() {
		return "Trip [trip_id=" + trip_id + ", destination=" + destination + ", departure_date=" + departure_date
				+ ", driver=" + driver + ", seat_type=" + seat_type + ", booked_ticket=" + booked_ticket
				+ ", max_ticket=" + max_ticket + "]";
	}

}
