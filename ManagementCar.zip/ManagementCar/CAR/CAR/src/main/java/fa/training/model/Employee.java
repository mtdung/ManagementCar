package fa.training.model;

public class Employee {
	private int emp_id;
	private String emp_name;
	private String dob;
	private int sex;
	private String address;
	private String phone;
	private String email;
	private String account;
	private String pass;
	private String dept;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Employee(int emp_id, String emp_name, String dob, int sex, String address, String phone, String email,
			String account, String pass, String dept) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.dob = dob;
		this.sex = sex;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.account = account;
		this.pass = pass;
		this.dept = dept;
	}


	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}
}
