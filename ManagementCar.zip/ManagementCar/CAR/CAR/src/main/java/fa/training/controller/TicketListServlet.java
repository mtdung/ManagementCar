package fa.training.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import fa.training.dao.TicketDAO;
import fa.training.dao.impl.TicketDAOImpl;
import fa.training.model.Employee;
import fa.training.model.TicketDTO;
import fa.training.utils.Constants;

/**
 * Servlet implementation class TicketListServlet
 */
@WebServlet("/TicketListServlet")
public class TicketListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TicketListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			if (request.getParameter("isReloaded") == null) {
				try {
					TicketDAO ticketDAO = new TicketDAOImpl();
					List<TicketDTO> ticketList = ticketDAO.getLatestTicketDTO(1);
					if (ticketList.isEmpty()) {
						request.setAttribute("generalAlert", "No ticket to display!");
					} else {
						Date selectedDate = ticketList.get(0).getDeparture_date();
						int day = selectedDate.toLocalDate().getDayOfMonth();
						int month = selectedDate.toLocalDate().getMonthValue();
						int year = selectedDate.toLocalDate().getYear();
						String filterBy = "All";
						String searchedPattern = "";
						int numberOfRecords = ticketDAO.getNumberOfTicketDTOByDate(selectedDate, filterBy,
								searchedPattern);
						int numberOfPages = numberOfRecords % Constants.PAGE_SIZE == 0
								? numberOfRecords / Constants.PAGE_SIZE
								: numberOfRecords / Constants.PAGE_SIZE + 1;
						int selectedPage = Constants.FIRST_PAGE;
						int totalTicketOnPages = ticketList.size();
						request.setAttribute("ticketList", ticketList);
						request.setAttribute("day", day);
						request.setAttribute("month", month);
						request.setAttribute("year", year);
						request.setAttribute("numberOfPages", numberOfPages);
						request.setAttribute("filterBy", filterBy);
						request.setAttribute("selectedPage", selectedPage);
						request.setAttribute("searchedPattern", searchedPattern);
						request.setAttribute("totalTicketOnPages", totalTicketOnPages);
					}
				} catch (Exception e) {
					request.setAttribute("generalAlert", "Error occured!");
				}
			} else {
				try {
					int selectedPage = Integer.parseInt(request.getParameter("selectedPage"));
					int day = Integer.parseInt(request.getParameter("day"));
					int month = Integer.parseInt(request.getParameter("month"));
					int year = Integer.parseInt(request.getParameter("year"));
					Date selectedDate = Date.valueOf(LocalDate.of(year, month, day));
					String filterBy = request.getParameter("filterBy");
					String searchedPattern = request.getParameter("searchedPattern");
					TicketDAO ticketDAO = new TicketDAOImpl();
					List<TicketDTO> ticketList = ticketDAO.searchTicket(selectedPage, selectedDate, filterBy,
							searchedPattern);
					if (ticketList.isEmpty()) {
						request.setAttribute("generalAlert", "No ticket to display!");
					} else {
						int numberOfRecords = ticketDAO.getNumberOfTicketDTOByDate(selectedDate, filterBy,
								searchedPattern);
						int numberOfPages = numberOfRecords % Constants.PAGE_SIZE == 0
								? numberOfRecords / Constants.PAGE_SIZE
								: numberOfRecords / Constants.PAGE_SIZE + 1;
						int totalTicketOnPages = ticketList.size();
						request.setAttribute("ticketList", ticketList);
						request.setAttribute("numberOfPages", numberOfPages);
						request.setAttribute("totalTicketOnPages", totalTicketOnPages);
					}
					if (!filterBy.equals("All")) {
						request.setAttribute("searchedPattern", searchedPattern);
					}
					request.setAttribute("filterBy", filterBy);
					request.setAttribute("day", day);
					request.setAttribute("month", month);
					request.setAttribute("year", year);
					request.setAttribute("selectedPage", selectedPage);
				} catch (Exception e) {
					request.setAttribute("generalAlert", e.getMessage());
					e.printStackTrace();
				}
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/TicketList.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String filterBy = request.getParameter("filterBy");
			String searchedPattern = request.getParameter("searchedPattern");
			int day = Integer.parseInt(request.getParameter("day"));
			int month = Integer.parseInt(request.getParameter("month"));
			int year = Integer.parseInt(request.getParameter("year"));
			Date selectedDate = Date.valueOf(LocalDate.of(year, month, day));
			TicketDAO ticketDAO = new TicketDAOImpl();
			List<TicketDTO> ticketList = ticketDAO.searchTicket(Constants.FIRST_PAGE, selectedDate, filterBy,
					searchedPattern);
			if (ticketList.isEmpty()) {
				request.setAttribute("generalAlert", "No ticket to display!");
			} else {
				int numberOfRecords = ticketDAO.getNumberOfTicketDTOByDate(selectedDate, filterBy, searchedPattern);
				int numberOfPages = numberOfRecords % Constants.PAGE_SIZE == 0 ? numberOfRecords / Constants.PAGE_SIZE
						: numberOfRecords / Constants.PAGE_SIZE + 1;
				int totalTicketOnPages = ticketList.size();
				request.setAttribute("ticketList", ticketList);
				request.setAttribute("numberOfPages", numberOfPages);
				request.setAttribute("totalTicketOnPages", totalTicketOnPages);
			}
			if (!filterBy.equals("All")) {
				request.setAttribute("searchedPattern", searchedPattern);
			}
			request.setAttribute("filterBy", filterBy);
			request.setAttribute("day", day);
			request.setAttribute("month", month);
			request.setAttribute("year", year);
			request.setAttribute("selectedPage", Constants.FIRST_PAGE);
		} catch (Exception e) {
			request.setAttribute("generalAlert", "Error occured!");
		} finally {
			request.getRequestDispatcher("views/TicketList.jsp").forward(request, response);
		}
	}

}
