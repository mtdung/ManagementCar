package fa.training.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.EmployeeDAO;
import fa.training.dao.impl.EmployeeDAOImpl;
import fa.training.model.Employee;

/**
 * Servlet implementation class SearchEmployeeController
 */
@WebServlet("/searchemployee")
public class SearchEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchEmployeeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	EmployeeDAO dao = new EmployeeDAOImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
		} else {
			loginStatus = 2;
			try {
				String filter = request.getParameter("filterBy");
				String textSearch = request.getParameter("textSearch");
				int index = 0;
				try {
					index = Integer.parseInt(request.getParameter("index"));
				} catch (Exception e) {
					index = 1;
				}
				int count = dao.countListEmployeeSearch(filter, textSearch);
				int size = 3;
				int lastPage = count / size;
				if (count % size != 0) {
					lastPage++;
				}
				if (filter.equals("all")) {
					response.sendRedirect(request.getContextPath() + "/listemployee");
					return;
				} else {
					List<Employee> listE = dao.getListEmployeeSearch(filter, textSearch, index, size);
					if (listE.size() > 0) {
						if (filter.equals("employee_id")) {
							request.setAttribute("select", 1);
						} else if (filter.equals("full_name")) {
							request.setAttribute("select", 2);
						} else if (filter.equals("dob")) {
							request.setAttribute("select", 3);
						} else if (filter.equals("address")) {
							request.setAttribute("select", 4);
						} else if (filter.equals("phone_number")) {
							request.setAttribute("select", 5);
						} else {
							request.setAttribute("select", 6);
						}
						request.setAttribute("filterBy", filter);
						request.setAttribute("textSearch", textSearch);
						request.setAttribute("index", index);
						request.setAttribute("lastPage", lastPage);
						request.setAttribute("listE", listE);
						request.setAttribute("check", true);
					} else {
						request.setAttribute("mess", "Result Empty!");
					}
				}
			} catch (Exception e) {
				request.setAttribute("mess", "Error occured!");
			}
		}
		switch (loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("TripListServlet").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("views/EmployeeList.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
