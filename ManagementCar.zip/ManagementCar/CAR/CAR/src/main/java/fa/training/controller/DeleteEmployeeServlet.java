package fa.training.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.EmployeeDAO;
import fa.training.dao.impl.EmployeeDAOImpl;
import fa.training.model.Employee;

/**
 * Servlet implementation class DeleteEmployeeServlet
 */
@WebServlet("/DeleteEmployeeServlet")
public class DeleteEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteEmployeeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
		} else {
			try {
				loginStatus = 2;
				long employee_id = Long.parseLong(request.getParameter("employee_id"));
				if (employee_id == selectedEmployee.getEmp_id()) {
					request.setAttribute("mess", "Can't delete your self, dumbass :))");
				} else {
					EmployeeDAO employeeDAO = new EmployeeDAOImpl();
					if (employeeDAO.deleteEmployee(employee_id)) {
						request.setAttribute("generalNoti", "Delete successful!");
					} else {
						request.setAttribute("mess", "Delete failed!!");
					}
				}
			} catch (Exception ex) {
				request.setAttribute("mess", "Error occured!");
			}
		}
		switch (loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("TripListServlet").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
