/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fa.training.dao.impl;

import fa.training.dao.BookOfficeDAO;
import fa.training.model.*;
import fa.training.utils.DBConnection;
import fa.training.utils.SQLCommand;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

/**
 *
 * @author Bau
 */
public class BookOfficeDAOImpl implements BookOfficeDAO {

    private Connection con;
    private PreparedStatement pre;
    private ResultSet rs;

    @Override
    public ArrayList<BookOffice> getBookOfficeList() throws SQLException {
        ArrayList<BookOffice> bookOfficeList = new ArrayList<>();

        try {
            con = new DBConnection().getConnection();
            pre = con.prepareStatement(SQLCommand.getBookOfficeList);
            rs = pre.executeQuery();
            while (rs.next()) {
                BookOffice A = new BookOffice();
                A.setId(rs.getInt("bookoffice_id"));
                A.setName(rs.getString("bookoffice_name"));
                A.setTripId(rs.getInt("trip_id"));
                A.setPhoneNumber(rs.getString("phone_number"));
                A.setPlace(rs.getString("place"));
                A.setPrice(rs.getInt("price"));
                A.setStartContract(rs.getDate("start_contract"));
                A.setEndContract(rs.getDate("end_contract"));
                bookOfficeList.add(A);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return bookOfficeList;
    }


    @Override
    public boolean AddBookOffice(BookOffice A) throws SQLException {
        int success = 0;
        try {
            con = new DBConnection().getConnection();
            pre = con.prepareStatement(SQLCommand.AddBookOffice);
            pre.setString(1, A.getName());
            pre.setString(2, A.getPhoneNumber());
            pre.setInt(3, A.getPrice());
            pre.setString(4, A.getPlace());
            pre.setInt(5, A.getTripId());
            pre.setDate(6, new java.sql.Date(A.getStartContract().getTime()));
            pre.setDate(7, new java.sql.Date(A.getEndContract().getTime()));
            success = pre.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return success > 0;
    }
    
    public static void main(String[] args) throws SQLException {
    	BookOffice book;
		try {
			book = new BookOffice("321", "1", "hfg", "3123123", "dsa", "11/11/2011", "11/11/2011");
			BookOfficeDAO dao = new BookOfficeDAOImpl();
			boolean b = dao.AddBookOffice(book);
			if(b) {
			System.out.println("OK");
			} else {
				System.out.println("Sai");
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

    @Override
    public ArrayList<BookOfficeDestination> getBookOfficeDestinationList(int index, int size) throws SQLException {
        ArrayList<BookOfficeDestination> bookOfficeList = new ArrayList<>();

        try {
            con = new DBConnection().getConnection();
            pre = con.prepareStatement(SQLCommand.getBookOfficeWithDestination);
            pre.setInt(1, (index - 1) * size);
            pre.setInt(2, size);
            rs = pre.executeQuery();
            while (rs.next()) {
                BookOfficeDestination A = new BookOfficeDestination();
                A.setId(rs.getInt("bookoffice_id"));
                A.setName(rs.getString("bookoffice_name"));
                A.setDestination(rs.getString("destination"));
                bookOfficeList.add(A);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return bookOfficeList;
    }

    @Override
    public int countBookOffice() throws SQLException {
        int count = 0;

        try {
            con = new DBConnection().getConnection();
            pre = con.prepareStatement(SQLCommand.countListBooking);
            rs = pre.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return count;
    }

    @Override
    public int countBookOfficeSearch(String filler, String key) throws SQLException {
        int count = 0;

        try {
            con = new DBConnection().getConnection();
            String sqlCommand = SQLCommand.countBookOfficeBySearch.replace(SQLCommand.STRING_TO_REPLACE, filler);
            pre = con.prepareStatement(sqlCommand);
            pre.setString(1, key + "%");
            rs = pre.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return count;
    }

    @Override
    public ArrayList<BookOfficeDestination> getBookOfficeDestinationListSearch(String filler, String key, int index, int size) throws SQLException {
        ArrayList<BookOfficeDestination> bookOfficeList = new ArrayList<>();

        try {
            con = new DBConnection().getConnection();
            String sqlCommand = SQLCommand.getBookOfficeWithDestinationSearch.replace(SQLCommand.STRING_TO_REPLACE, filler);
            pre = con.prepareStatement(sqlCommand);
            pre.setString(1, key + "%");
            pre.setInt(2, (index - 1) * size);
            pre.setInt(3, size);
            rs = pre.executeQuery();
            while (rs.next()) {
                BookOfficeDestination A = new BookOfficeDestination();
                A.setId(rs.getInt("bookoffice_id"));
                A.setName(rs.getString("bookoffice_name"));
                A.setDestination(rs.getString("destination"));
                bookOfficeList.add(A);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return bookOfficeList;
    }

    @Override
    public BookOffice getBookOfficeFromId(int id) throws SQLException {
        BookOffice A = new BookOffice();

        try {
            con = new DBConnection().getConnection();
            pre = con.prepareStatement(SQLCommand.getBookOfficeFromID);
            pre.setInt(1, id);
            rs = pre.executeQuery();
            while (rs.next()) {
                A.setId(rs.getInt("bookoffice_id"));
                A.setName(rs.getString("bookoffice_name"));
                A.setTripId(rs.getInt("trip_id"));
                A.setPhoneNumber(rs.getString("phone_number"));
                A.setPlace(rs.getString("place"));
                A.setPrice(rs.getInt("price"));
                A.setStartContract(rs.getDate("start_contract"));
                A.setEndContract(rs.getDate("end_contract"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return A;
    }

    @Override
    public String getDestinationFromTripID(int id) throws SQLException {
        String destination = "";

        try {
            con = new DBConnection().getConnection();
            pre = con.prepareStatement(SQLCommand.getDestinationFromID);
            pre.setInt(1, id);
            rs = pre.executeQuery();
            while (rs.next()) {
                destination = rs.getString("destination");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pre != null) {
                pre.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return destination;
    }

}
