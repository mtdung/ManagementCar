package fa.training.dao;

import java.sql.SQLException;
import java.util.List;

import fa.training.model.Employee;

public interface EmployeeDAO {
	Employee getEmployeeByAccount(String account) throws SQLException;

	boolean addEmployee(String name, String dob, int sex, String address, String phone, String email, String account,
			String pass, String dept) throws SQLException;

	List<Employee> getListEmployee(int index, int size) throws SQLException;

	int countListEmployee() throws SQLException;

	int countListEmployeeSearch(String text1, String text2) throws SQLException;

	List<Employee> getListEmployeeSearch(String text1, String text2, int index, int size) throws SQLException;

	Employee viewEmployee(int id) throws SQLException;
	
	boolean deleteEmployee(long employee_id) throws SQLException;
}
