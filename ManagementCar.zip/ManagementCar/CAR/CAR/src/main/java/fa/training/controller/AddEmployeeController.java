package fa.training.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.EmployeeDAO;
import fa.training.dao.impl.EmployeeDAOImpl;
import fa.training.model.Employee;

/**
 * Servlet implementation class AddEmployeeController
 */
@WebServlet("/addemployee")
public class AddEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
		}else {
			loginStatus = 2;
			request.setAttribute("sex", 0);
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("TripListServlet").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("views/AddEmployee.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String name = request.getParameter("name");
			String phone = request.getParameter("phone");
			int sex = Integer.parseInt(request.getParameter("sex"));
			String dob = request.getParameter("dateOfBirth");
			String address = request.getParameter("address");
			String email = request.getParameter("email");
			String account = request.getParameter("account");
			String pass = request.getParameter("password");
			String dept = request.getParameter("department");
			EmployeeDAO dao = new EmployeeDAOImpl();
			boolean check = dao.addEmployee(name, dob, sex, address, phone, email, account, pass, dept);
			if(check) {
				request.setAttribute("generalNoti", "Add successful!");
			}
			else {
				request.setAttribute("mess", "Add failed!");
				request.setAttribute("name", name);
				request.setAttribute("phone", phone);
				request.setAttribute("sex", sex);
				request.setAttribute("dob", dob);
				request.setAttribute("email", email);
				request.setAttribute("address", address);
				request.setAttribute("account", account);
				request.setAttribute("pass", pass);
				if(dept.equals("Admin")){
					request.setAttribute("dept", 1);
				}else {
					request.setAttribute("dept", 2);
				}
			}
		} catch (Exception e) {
			request.setAttribute("mess", "Error occured!");
		} finally {
			request.getRequestDispatcher("views/AddEmployee.jsp").forward(request, response);
		}
	}

}
