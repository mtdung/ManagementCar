package fa.training.model;

public class Parking {
	private long park_id;
	private String name_park;
	private String place;
	private long area;
	private long price;
	private int status_park;
	
	public Parking(long park_id, String name_park, String place, long area, long price, int status_park) {
		super();
		this.park_id = park_id;
		this.name_park = name_park;
		this.place = place;
		this.area = area;
		this.price = price;
		this.status_park = status_park;
	}

	public Parking() {
		// TODO Auto-generated constructor stub
	}
	
	public Parking(int park_id, String park_name) {
		super();
		this.park_id = park_id;
		this.name_park = park_name;
	}

	public long getPark_id() {
		return park_id;
	}

	public void setPark_id(long park_id) {
		this.park_id = park_id;
	}

	public String getName_park() {
		return name_park;
	}

	public void setName_park(String name_park) {
		this.name_park = name_park;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public long getArea() {
		return area;
	}

	public void setArea(long area) {
		this.area = area;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public int getStatus_park() {
		return status_park;
	}

	public void setStatus_park(int status_park) {
		this.status_park = status_park;
	}

	@Override
	public String toString() {
		return "Parking [park_id=" + park_id + ", name_park=" + name_park + ", place=" + place + ", area=" + area
				+ ", price=" + price + ", status_park=" + status_park + "]";
	}	
}
