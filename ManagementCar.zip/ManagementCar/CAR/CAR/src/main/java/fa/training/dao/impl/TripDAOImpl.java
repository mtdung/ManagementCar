package fa.training.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import fa.training.dao.TripDAO;
import fa.training.model.Trip;
import fa.training.utils.DBConnection;
import fa.training.utils.SQLCommand;

public class TripDAOImpl implements TripDAO {

	private Connection con;
	private PreparedStatement stm;
	private ResultSet rs;

	@Override
	public List<Trip> getAllTrips() throws SQLException {
		List<Trip> tripList = new ArrayList<>();
		Trip currentTrip = null;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_ALL_TRIPS);
			rs = stm.executeQuery();
			while (rs.next()) {
				currentTrip = new Trip();
				currentTrip.setTrip_id(rs.getLong("trip_id"));
				currentTrip.setDestination(rs.getString("destination"));
				currentTrip.setDeparture_date(rs.getTimestamp("depature_date"));
				currentTrip.setDriver(rs.getString("driver"));
				currentTrip.setSeat_type(rs.getString("seat_type"));
				currentTrip.setBooked_ticket(rs.getInt("booked_ticket"));
				currentTrip.setMax_ticket(rs.getInt("max_ticket"));
				tripList.add(currentTrip);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return tripList;
	}

	@Override
	public boolean addTrip(Trip trip) throws SQLException {
		if (trip == null)
			return false;
		boolean isAdded = false;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.ADD_TRIP);
			stm.setString(1, trip.getDestination());
			stm.setTimestamp(2, trip.getDeparture_date());
			stm.setString(3, trip.getDriver());
			stm.setString(4, trip.getSeat_type());
			stm.setInt(5, trip.getBooked_ticket());
			stm.setInt(6, trip.getMax_ticket());
			isAdded = stm.executeUpdate() != 0 ? true : false;
		} finally {
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return isAdded;
	}

	@Override
	public List<Trip> getTripsByDateWithPaging(Date date, int page, int pageSize) throws SQLException {
		List<Trip> tripList = new ArrayList<>();
		if (page <= 0 || pageSize <= 0 || date == null) {
			return tripList;
		}
		Trip currentTrip = null;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_TRIPS_BY_DATE);
			stm.setDate(1, date);
			stm.setInt(2, pageSize * page - pageSize + 1);
			stm.setInt(3, pageSize * page);
			rs = stm.executeQuery();
			while (rs.next()) {
				currentTrip = new Trip();
				currentTrip.setTrip_id(rs.getLong("trip_id"));
				currentTrip.setDestination(rs.getString("destination"));
				currentTrip.setDeparture_date(rs.getTimestamp("depature_date"));
				currentTrip.setDriver(rs.getString("driver"));
				currentTrip.setSeat_type(rs.getString("seat_type"));
				currentTrip.setBooked_ticket(rs.getInt("booked_ticket"));
				currentTrip.setMax_ticket(rs.getInt("max_ticket"));
				tripList.add(currentTrip);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return tripList;
	}

	@Override
	public List<Trip> getAllTripsWithPaging(int page, int pageSize) throws SQLException {
		List<Trip> tripList = new ArrayList<>();
		if (page <= 0 || pageSize <= 0) {
			return tripList;
		}
		Trip currentTrip = null;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_ALL_TRIPS);
			stm.setInt(1, pageSize * page - pageSize + 1);
			stm.setInt(2, pageSize * page);
			rs = stm.executeQuery();
			while (rs.next()) {
				currentTrip = new Trip();
				currentTrip.setTrip_id(rs.getLong("trip_id"));
				currentTrip.setDestination(rs.getString("destination"));
				currentTrip.setDeparture_date(rs.getTimestamp("depature_date"));
				currentTrip.setDriver(rs.getString("driver"));
				currentTrip.setSeat_type(rs.getString("seat_type"));
				currentTrip.setBooked_ticket(rs.getInt("booked_ticket"));
				currentTrip.setMax_ticket(rs.getInt("max_ticket"));
				tripList.add(currentTrip);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return tripList;
	}

	@Override
	public List<Trip> searchTrip(Date date, String destination, int page, int pageSize) throws SQLException {
		List<Trip> tripList = new ArrayList<>();
		if (page <= 0 || pageSize <= 0 || date == null) {
			return tripList;
		}
		Trip currentTrip = null;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.SEARCH_TRIP_QUERY);
			stm.setDate(1, date);
			String destinationPattern = '%' + destination + '%';
			stm.setString(2, destinationPattern);
			stm.setInt(3, pageSize * page - pageSize + 1);
			stm.setInt(4, pageSize * page);
			rs = stm.executeQuery();
			while (rs.next()) {
				currentTrip = new Trip();
				currentTrip.setTrip_id(rs.getLong("trip_id"));
				currentTrip.setDestination(rs.getString("destination"));
				currentTrip.setDeparture_date(rs.getTimestamp("depature_date"));
				currentTrip.setDriver(rs.getString("driver"));
				currentTrip.setSeat_type(rs.getString("seat_type"));
				currentTrip.setBooked_ticket(rs.getInt("booked_ticket"));
				currentTrip.setMax_ticket(rs.getInt("max_ticket"));
				tripList.add(currentTrip);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return tripList;
	}

	@Override
	public int getNumberOfTrips(Date date, String destination) throws SQLException {
		if (date == null || destination == null)
			return 0;
		int count = 0;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_TOTAL_TRIPS);
			stm.setDate(1, date);
			String destinationPattern = '%' + destination + '%';
			stm.setString(2, destinationPattern);
			rs = stm.executeQuery();
			while (rs.next()) {
				count++;
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return count;
	}

	@Override
	public List<Trip> getLatestTripsWithPaging(int selectedPage, int pageSize) throws SQLException {
		if (selectedPage <= 0 || pageSize <= 0) {
			return new ArrayList<>();
		}
		List<Trip> allTrips = new ArrayList<>();
		Trip currentTrip = null;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_LATEST_TRIP);
			stm.setInt(1, pageSize * selectedPage - pageSize + 1);
			stm.setInt(2, pageSize * selectedPage);
			rs = stm.executeQuery();
			while (rs.next()) {
				currentTrip = new Trip();
				currentTrip.setTrip_id(rs.getLong("trip_id"));
				currentTrip.setDestination(rs.getString("destination"));
				currentTrip.setDeparture_date(rs.getTimestamp("depature_date"));
				currentTrip.setDriver(rs.getString("driver"));
				currentTrip.setSeat_type(rs.getString("seat_type"));
				currentTrip.setBooked_ticket(rs.getInt("booked_ticket"));
				currentTrip.setMax_ticket(rs.getInt("max_ticket"));
				allTrips.add(currentTrip);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return allTrips;
	}

	@Override
	public boolean deleteTrip(int trip_id) throws SQLException {
		boolean isDeleted = false;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.DELETE_TRIP);
			stm.setInt(1, trip_id);
			stm.setInt(2, trip_id);
			stm.setInt(3, trip_id);
			isDeleted = stm.executeUpdate() > 0;
		} finally {
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return isDeleted;
	}

	@Override
	public boolean editTrip(Trip trip) throws SQLException {
		if (trip == null)
			return false;
		boolean isEdited = false;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.EDIT_TRIP);
			stm.setString(1, trip.getDestination());
			stm.setTimestamp(2, trip.getDeparture_date());
			stm.setString(3, trip.getDriver());
			stm.setString(4, trip.getSeat_type());
			stm.setInt(5, trip.getMax_ticket());
			stm.setLong(6, trip.getTrip_id());
			isEdited = stm.executeUpdate() > 0;
		} finally {
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return isEdited;
	}

	@Override
	public Trip getTripByID(int trip_id) throws SQLException {
		Trip selectedTrip = null;
		try {
			con = DBConnection.getInstance().getConnection();
			stm = con.prepareStatement(SQLCommand.GET_TRIP_BY_ID);
			stm.setInt(1, trip_id);
			rs = stm.executeQuery();
			if(rs.next()) {
				selectedTrip = new Trip();
				selectedTrip.setTrip_id(rs.getLong("trip_id"));
				selectedTrip.setDestination(rs.getString("destination"));
				selectedTrip.setDeparture_date(rs.getTimestamp("depature_date"));
				selectedTrip.setDriver(rs.getString("driver"));
				selectedTrip.setSeat_type(rs.getString("seat_type"));
				selectedTrip.setBooked_ticket(rs.getInt("booked_ticket"));
				selectedTrip.setMax_ticket(rs.getInt("max_ticket"));
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return selectedTrip;
	}

}
