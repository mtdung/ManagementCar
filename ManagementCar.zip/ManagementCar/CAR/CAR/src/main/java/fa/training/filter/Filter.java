package fa.training.filter;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet Filter implementation class Filter
 */
@WebFilter(filterName = "/Filter", urlPatterns = { "/views/Login.jsp", "/views/AddBookingOffice.jsp",
		"/views/AddCar.jsp", "/views/AddEmployee.jsp", "/views/AddParking.jsp", "/views/AddTicket.jsp",
		"/views/AddTrip.jsp", "/views/CarList.jsp", "/views/EditParking.jsp", "/views/EditTrip.jsp",
		"/views/EmployeeList.jsp", "/views/ParkingLotList.jsp", "/views/TicketList.jsp", "/views/TripList.jsp",
		"/views/UpdateCar.jsp", "/views/ViewBookingOffice.jsp", "/views/ViewEmployee.jsp",
		"/views/viewOneBookOffice.jsp" })
public class Filter implements javax.servlet.Filter {
	static boolean pass = false;

	/**
	 * Default constructor.
	 */
	public Filter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		int indexOfLink = ((HttpServletRequest) request).getRequestURI().indexOf("views");
		if (indexOfLink == -1) {
			chain.doFilter(request, response);
		} else {
			int indexOfEndLink = ((HttpServletRequest) request).getRequestURI().indexOf(".jsp");
			String prefix = ((HttpServletRequest) request).getRequestURI().substring(0, indexOfLink);
			String path = ((HttpServletRequest) request).getRequestURI().substring(indexOfLink + 6, indexOfEndLink + 4);
			System.out.println(prefix);
			switch (path) {
			case "AddBookingOffice.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "addbookoffice");
				break;
			case "AddCar.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "addcar");
				break;
			case "AddEmployee.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "addemployee");
				break;
			case "AddParking.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "AddController");
				break;
			case "AddTicket.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "AddTicketServlet");
				break;
			case "AddTrip.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "AddTripServlet");
				break;
			case "CarList.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "listcar");
				break;
			case "EditParking.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "EditController");
				break;
			case "EditTrip.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "EditTripServlet");
				break;
			case "EmployeeList.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "listemployee");
				break;
			case "Login.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "LoginServlet");
				break;
			case "ParkingLotList.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "listParking");
				break;
			case "TicketList.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "TicketListServlet");
				break;
			case "TripList.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "TripListServlet");
				break;
			case "UpdateCar.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "updatecar");
				break;
			case "ViewBookingOffice.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "viewbookoffice");
				break;
			case "ViewEmployee.jsp":
				((HttpServletResponse) response).sendRedirect(prefix + "viewemployee");
				break;
			default:
				((HttpServletResponse) response).sendRedirect(prefix + "viewOneBookOffice");
				break;
			}
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
