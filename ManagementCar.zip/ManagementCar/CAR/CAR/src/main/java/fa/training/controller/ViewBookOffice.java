/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fa.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.impl.BookOfficeDAOImpl;
import fa.training.model.BookOfficeDestination;
import fa.training.model.Employee;

@WebServlet("/viewbookoffice")
public class ViewBookOffice extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	BookOfficeDAOImpl BDB = new BookOfficeDAOImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			try {
				int index = 0;
				try {
					index = Integer.parseInt(request.getParameter("index"));
				} catch (Exception e) {
					index = 1;
				}
				int count = BDB.countBookOffice();
				int size = 3;
				int lastPage = count / size;
				if (count % size != 0) {
					lastPage++;
				}
				ArrayList<BookOfficeDestination> listB = BDB.getBookOfficeDestinationList(index, size);
				if (listB.size() > 0) {
					request.setAttribute("index", index);
					request.setAttribute("lastPage", lastPage);
					request.setAttribute("listB", listB);
					request.setAttribute("check", false);
				} else {
					request.setAttribute("mess", "List booking empty!");
				}
			} catch (SQLException e) {
				request.setAttribute("mess", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/ViewBookingOffice.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
