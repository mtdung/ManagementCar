package fa.training.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fa.training.dao.EmployeeDAO;
import fa.training.dao.impl.EmployeeDAOImpl;
import fa.training.model.Employee;
import fa.training.utils.DBConnection;
import fa.training.utils.SQLCommand;

public class EmployeeDAOImpl implements EmployeeDAO {

	private Connection con;
	private PreparedStatement pre;
	private ResultSet rs;

	@Override
	public Employee getEmployeeByAccount(String account) throws SQLException {
		if(account == null || account.trim().isEmpty()) return null;
		Employee employee = null;
		try {
			con = DBConnection.getInstance().getConnection();
			pre = con.prepareStatement(SQLCommand.GET_EMPLOYEE_BY_ACCOUNT);
			pre.setString(1, account);
			rs = pre.executeQuery();
			if (rs.next()) {
				employee = new Employee();
				employee.setEmp_id(rs.getInt("employee_id"));
				employee.setEmp_name(rs.getString("full_name"));
				employee.setDob(rs.getString("dob"));
				employee.setSex(rs.getInt("sex"));
				employee.setAddress(rs.getString("address"));
				employee.setPhone(rs.getString("phone_number"));
				employee.setEmail(rs.getString("email"));
				employee.setAccount(account);
				employee.setPass(rs.getString("password"));
				employee.setDept(rs.getString("department"));
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return employee;
	}
	
	@Override
	public boolean addEmployee(String name, String dob, int sex, String address, String phone, String email,
			String account, String pass, String dept) throws SQLException {
		int row = 0;
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.addEmployee);
			pre.setString(1, name);
			pre.setString(2, dob);
			pre.setInt(3, sex);
			pre.setString(4, address);
			pre.setString(5, phone);
			pre.setString(6, email);
			pre.setString(7, account);
			pre.setString(8, pass);
			pre.setString(9, dept);
			row = pre.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return row > 0;
	}

	@Override
	public int countListEmployee() throws SQLException {
		int count = 0;
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.countListEmployee);
			rs = pre.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return count;
	}

	@Override
	public List<Employee> getListEmployee(int index , int size) throws SQLException {
		List<Employee> listE = new ArrayList<>();
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.getListEmployeePaging);
			pre.setInt(1, (index-1)*size);
			pre.setInt(2, size);
			rs = pre.executeQuery();
			while(rs.next()) {
				listE.add(new Employee(rs.getInt("employee_id") , rs.getString("full_name"), rs.getString("dob"), rs.getInt("sex"), rs.getString("address"), 
						rs.getString("phone_number"), rs.getString("email"), rs.getString("account"), rs.getString("password"), rs.getString("department")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return listE;
	}
	@Override
	public int countListEmployeeSearch(String text1, String text2) throws SQLException {
		int count = 0;
		try {
			con = new DBConnection().getConnection();
			String newSQlCommand = SQLCommand.countListEmployeeSearch.replace(SQLCommand.randomText, text1);
			pre = con.prepareStatement(newSQlCommand);
			pre.setString(1, "%" + text2 + "%");
			rs = pre.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return count;
	}

	@Override
	public List<Employee> getListEmployeeSearch(String text1, String text2, int index, int size) throws SQLException {
		List<Employee> listE = new ArrayList<>();
		try {
			con = new DBConnection().getConnection();
			String newSQLCommand = SQLCommand.getListEmployeeSearchPaging.replace(SQLCommand.randomText, text1);
			pre = con.prepareStatement(newSQLCommand);
			pre.setString(1,"%" + text2 + "%");
			pre.setInt(2, (index-1)*size);
			pre.setInt(3, size);
			rs = pre.executeQuery();
			while(rs.next()) {
				listE.add(new Employee(rs.getInt("employee_id") , rs.getString("full_name"), rs.getString("dob"), rs.getInt("sex"), rs.getString("address"), 
						rs.getString("phone_number"), rs.getString("email"), rs.getString("account"), rs.getString("password"), rs.getString("department")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return listE;
	}

	@Override
	public Employee viewEmployee(int id) throws SQLException {
		Employee e = new Employee();
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.viewEmployee);
			pre.setInt(1, id);
			rs = pre.executeQuery();
			while(rs.next()) {
				e = new Employee(rs.getInt("employee_id") , rs.getString("full_name"), rs.getString("dob"), rs.getInt("sex"), rs.getString("address"), 
						rs.getString("phone_number"), rs.getString("email"), rs.getString("account"), rs.getString("password"), rs.getString("department"));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return e;
	}

	public static void main1(String[] args) throws SQLException {
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		Employee employee = employeeDAO.getEmployeeByAccount("emp1fpt");
		System.out.println(employee);
	}

	@Override
	public boolean deleteEmployee(long employee_id) throws SQLException {
		boolean isDeleted = false;
		try {
			con = DBConnection.getInstance().getConnection();
			pre = con.prepareStatement(SQLCommand.DELETE_EMPLOYEE);
			pre.setLong(1, employee_id);
			isDeleted = pre.executeUpdate() > 0;
		} finally {
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return isDeleted;
	}
}
