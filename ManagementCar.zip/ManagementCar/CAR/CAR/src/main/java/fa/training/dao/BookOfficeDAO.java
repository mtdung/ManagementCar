/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fa.training.dao;


import java.sql.SQLException;
import java.util.ArrayList;

import fa.training.model.BookOffice;
import fa.training.model.BookOfficeDestination;

/**
 *
 * @author Bau
 */
public interface BookOfficeDAO {
    
    ArrayList<BookOffice> getBookOfficeList() throws SQLException;
    
    boolean AddBookOffice(BookOffice A) throws SQLException;
    
    ArrayList<BookOfficeDestination> getBookOfficeDestinationList(int index, int size) throws SQLException;
    
    int countBookOffice() throws SQLException;
    
    int countBookOfficeSearch(String filler, String key) throws SQLException;
    
    ArrayList<BookOfficeDestination> getBookOfficeDestinationListSearch(String filler, String key, int index, int size) throws SQLException;
    
    BookOffice getBookOfficeFromId(int id) throws SQLException;
    
    String getDestinationFromTripID(int id) throws SQLException;
    
}
