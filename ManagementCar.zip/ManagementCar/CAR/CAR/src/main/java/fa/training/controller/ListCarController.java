package fa.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.CarDAO;
import fa.training.dao.impl.CarDAOImpl;
import fa.training.model.Car;
import fa.training.model.Employee;

/**
 * Servlet implementation class ListCarController
 */
@WebServlet("/listcar")
public class ListCarController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ListCarController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	CarDAO carDAO = new CarDAOImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Employee")) {
			loginStatus = 1;
			try {
				int index = 0;
				try {
					index = Integer.parseInt(request.getParameter("index"));
				} catch (Exception e) {
					index = 1;
				}
				int count = carDAO.countListCar();
				int size = 3;
				int lastPage = count / size;
				if (count % size != 0) {
					lastPage++;
				}
				List<Car> listC = carDAO.getListCar(index, size);
				if (listC.size() > 0) {
					request.setAttribute("index", index);
					request.setAttribute("lastPage", lastPage);
					request.setAttribute("listC", listC);
					request.setAttribute("check", false);
				} else {
					request.setAttribute("mess", "List Car empty!");
				}
			} catch (SQLException e) {
				request.setAttribute("mess", "Error occured!");
			}
		}else {
			loginStatus = 2;
		}
		switch(loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/CarList.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
