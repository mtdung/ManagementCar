package fa.training.model;

public class Car {
	private String license;
	private String type;
	private String color;
	private String company;
	private int park_id;
	
	public Car() {
		// TODO Auto-generated constructor stub
	}

	public Car(String license, String type, String color, String company, int park_id) {
		super();
		this.license = license;
		this.type = type;
		this.color = color;
		this.company = company;
		this.park_id = park_id;
	}

	public String getLicense() {
		return license;
	}

	public void setLicense(String license) {
		this.license = license;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public int getPark_id() {
		return park_id;
	}

	public void setPark_id(int park_id) {
		this.park_id = park_id;
	}

	@Override
	public String toString() {
		return "Car [license=" + license + ", type=" + type + ", color=" + color + ", company=" + company + ", park_id="
				+ park_id + "]";
	}
	
	
	
}
