package fa.training.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import fa.training.dao.impl.*;
import fa.training.model.Employee;
import fa.training.dao.EmployeeDAO;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//xu li login (session)
		HttpSession session = request.getSession();
		if(session.getAttribute("employee")!= null) {
			request.setAttribute("generalNoti", "You've already logged in!");
			Employee employee = (Employee) session.getAttribute("employee");
			if(employee.getDept().equals("Admin")) {
				request.getRequestDispatcher("listemployee").forward(request, response);
			}
			else {
				request.getRequestDispatcher("TripListServlet").forward(request, response);
			}
		}
		else {
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String account = request.getParameter("account");
		String password = request.getParameter("password");
		boolean isLogged = false;
		Employee employee = null;
		try {
			EmployeeDAO employeeDAO = new EmployeeDAOImpl();
			employee = employeeDAO.getEmployeeByAccount(account);
			if(employee == null) {
				request.setAttribute("accountAlert", "Account does not exist!");
			}
			else if(!employee.getPass().equals(password)) {
				request.setAttribute("passwordAlert", "Password is not correct!");
			}
			else {
				HttpSession session = request.getSession();
				session.setAttribute("employee", employee);
				isLogged = true;
				request.setAttribute("", session);
			}
		} catch (Exception e) {
			request.setAttribute("generalAlert", "Error occured!");
		} finally {
			if(isLogged) {
				if(employee.getDept().equals("Admin")) {
					response.sendRedirect("listemployee");
				} else {
					response.sendRedirect("TripListServlet");
				}
			}
			else {
				request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			}
		}
	}

}
