package fa.training.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import fa.training.dao.CarDAO;
import fa.training.model.Car;
import fa.training.utils.DBConnection;
import fa.training.utils.SQLCommand;

public class CarDAOImpl implements CarDAO{
	
	private Connection con;
	private PreparedStatement pre;
	private ResultSet rs;
	
	@Override
	public List<Car> getListCar(int index , int size) throws SQLException {
		List<Car> listC = new ArrayList<>();
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.getListCarPaging);
			pre.setInt(1, (index-1)*size);
			pre.setInt(2, size);
			rs = pre.executeQuery();
			while(rs.next()) {
				listC.add(new Car(rs.getString("license_plate"), rs.getString("car_type"), rs.getString("car_color")
						, rs.getString("company"), rs.getInt("park_id")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return listC;
	}
	
	@Override
	public boolean addCar(String lic, String type, String color, String company, String park_id) throws SQLException {
		int row = 0;
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.addCar);
			pre.setString(1, lic);
			pre.setString(2, type);
			pre.setString(3, color);
			pre.setString(4, company);
			pre.setString(5, park_id);
			row = pre.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return row > 0;
	}

	@Override
	public int countListCar() throws SQLException {
		int count = 0;
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.countListCar);
			rs = pre.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return count;
	}
	@Override
	public boolean deleteCar(String lic) throws SQLException {
		int row = 0;
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.deleteCar);
			pre.setString(1, lic);
			pre.setString(2, lic);
			row = pre.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return row > 0;
	}

	@Override
	public boolean updateCar(String lic, String type, String color, String company, long parkinglot)
			throws SQLException {
		int row = 0;
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.updateCar);
			pre.setString(1, type);
			pre.setString(2, color);
			pre.setString(3, company);
			pre.setLong(4, parkinglot);
			pre.setString(5, lic);
			row = pre.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return row > 0;
	}

	@Override
	public Car getCarbyLicense(String lic) throws SQLException {
		try {
			con = new DBConnection().getConnection();
			pre = con.prepareStatement(SQLCommand.getCarbyLicense);
			pre.setString(1 , lic);
			rs = pre.executeQuery();
			while(rs.next()) {
				Car c = new Car(rs.getString("license_plate"), rs.getString("car_type"), rs.getString("car_color")
						, rs.getString("company"), rs.getInt("park_id"));
				return c;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return null;
	}

	@Override
	public int countListCarSearch(String txt1, String txt2) throws SQLException {
		int count = 0;
		try {
			con = new DBConnection().getConnection();
			/*
			 * if(txt1.equals("license_plate")) { pre =
			 * con.prepareStatement(SQLCommand.countListCarSearchbyLicense); }else
			 * if(txt1.equals("car_type")) { pre =
			 * con.prepareStatement(SQLCommand.countListCarSearchbyType); }else
			 * if(txt1.equals("car_color")) { pre =
			 * con.prepareStatement(SQLCommand.countListCarSearchbyColor); }else
			 * if(txt1.equals("company")) { pre =
			 * con.prepareStatement(SQLCommand.countListCarSearchbyCompany); }else { pre =
			 * con.prepareStatement(SQLCommand.countListCarSearchbyPark); }
			 */
			String newSQlCommand = SQLCommand.countListCarSearch.replace(SQLCommand.randomText, txt1);
			pre = con.prepareStatement(newSQlCommand);
			pre.setString(1, "%"+txt2+"%");
			rs = pre.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return count;
	}
	
	@Override
	public List<Car> getListCarSearch(String txt1, String txt2, int index, int size) throws SQLException {
		List<Car> listC = new ArrayList<>();
		try {
			con = new DBConnection().getConnection();
			/*
			 * if(txt1.equals("license_plate")) { pre =
			 * con.prepareStatement(SQLCommand.getListCarSearchPagingbyLicense); }else
			 * if(txt1.equals("car_type")) { pre =
			 * con.prepareStatement(SQLCommand.getListCarSearchPagingbyType); }else
			 * if(txt1.equals("car_color")) { pre =
			 * con.prepareStatement(SQLCommand.getListCarSearchPagingbyColor); }else
			 * if(txt1.equals("company")) { pre =
			 * con.prepareStatement(SQLCommand.getListCarSearchPagingbyCompany); }else { pre
			 * = con.prepareStatement(SQLCommand.getListCarSearchPagingbyPark); }
			 */
			String newSQlCommand = SQLCommand.getListCarSearchPaging.replace(SQLCommand.randomText, txt1);
			pre = con.prepareStatement(newSQlCommand);
			pre.setString(1, "%"+txt2+"%");
			pre.setInt(2, (index-1)*size);
			pre.setInt(3, size);
			rs = pre.executeQuery();
			while(rs.next()) {
				listC.add(new Car(rs.getString("license_plate"), rs.getString("car_type"), rs.getString("car_color")
						, rs.getString("company"), rs.getInt("park_id")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pre != null) {
				pre.close();
			}
			if (con != null) {
				con.close();
			}
		}
		return listC;
	}
	
	public static void main(String[] args) {
		CarDAO dao = new CarDAOImpl();
		try {
			List<Car> listC = dao.getListCarSearch("car_type", "3" , 1 , 3);
			for (Car car : listC) {
				System.out.println(car);
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
