package fa.training.dao;

import java.sql.SQLException;
import java.util.List;

import fa.training.model.Car;

public interface CarDAO {
	List<Car> getListCar(int index , int size) throws SQLException;
	
	int countListCar() throws SQLException;
	
	boolean addCar(String lic , String type , String color , String company , String park_id) throws SQLException;
	
	boolean deleteCar(String lic) throws SQLException;
	
	boolean updateCar(String lic , String type , String color , String company , long parkinglot) throws SQLException;
	
	Car getCarbyLicense(String lic) throws SQLException;
	
	int countListCarSearch(String txt1 , String txt2) throws SQLException;
	
	List<Car> getListCarSearch(String txt1 , String txt2 , int index , int size) throws SQLException;
}
