package fa.training.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import fa.training.model.Trip;

public interface TripDAO {
	List<Trip> getAllTrips() throws SQLException;
	boolean addTrip(Trip trip) throws SQLException;
	List<Trip> getTripsByDateWithPaging(Date date, int page, int pageSize) throws SQLException;
	List<Trip> getAllTripsWithPaging(int page, int pageSize) throws SQLException;
	List<Trip> searchTrip(Date date, String destination, int page, int pageSize) throws SQLException;
	int getNumberOfTrips(Date date, String destination) throws SQLException;
	
	Trip getTripByID(int trip_id) throws SQLException;
	List<Trip> getLatestTripsWithPaging(int selectedPage, int pageSize) throws SQLException;
	boolean deleteTrip(int trip_id) throws SQLException;
	boolean editTrip(Trip trip) throws SQLException;
}
