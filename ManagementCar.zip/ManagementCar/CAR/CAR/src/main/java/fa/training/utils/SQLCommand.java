package fa.training.utils;

public class SQLCommand {
	public final static String STRING_TO_REPLACE = "BLAHBLAH";

	public final static String randomString = "random";

	public static final String FILTER_PART = " AND x." + STRING_TO_REPLACE + " LIKE ?";

	public final static String GET_ALL = "WITH X AS(SELECT ROW_NUMBER() OVER (ORDER BY park_id ASC) AS R, * FROM PARKINGLOT)\r\n"
			+ "SELECT * FROM X WHERE R BETWEEN ?*?-(?-1) AND ?*?";

	public final static String GET_ALL_BY = "WITH X AS(SELECT ROW_NUMBER() OVER (ORDER BY park_id ASC) AS R, * FROM PARKINGLOT WHERE "
			+ randomString + " like '%' + ? + '%')\n" + "SELECT * FROM X WHERE R BETWEEN ?*?-(?-1) AND ?*?";

	public final static String GET_DELETE = "DELETE TICKET WHERE license_plate IN (SELECT license_plate FROM CAR WHERE park_id = ?)\r\n"
			+ "DELETE CAR WHERE park_id = ?\r\n" + "DELETE PARKINGLOT WHERE park_id = ?";

	public final static String GET_EDIT = "UPDATE PARKINGLOT\r\n"
			+ "SET name_park = ?, place = ?, area = ?, price = ?, status_park = ?\r\n" + "WHERE park_id = ? ";

	public final static String GET_COUNT_BY = "SELECT COUNT(*) FROM PARKINGLOT WHERE " + randomString
			+ " like '%' + ? + '%'";

	public final static String GET_ADD = "INSERT INTO PARKINGLOT VALUES(?,?,?,?,?)";

	public final static String GET_SELECT_PARKING = "SELECT * FROM PARKINGLOT WHERE park_id = ?";

	public final static String countListCarSearchbyLicense = "SELECT COUNT(*) FROM CAR WHERE " + STRING_TO_REPLACE
			+ " = ?";

	public final static String getListCarSearchPagingbyLicense = "SELECT * FROM CAR WHERE license_plate = ? ORDER BY license_plate OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String countListCarSearchbyType = "SELECT COUNT(*) FROM CAR WHERE car_type = ?";

	public final static String getListCarSearchPagingbyType = "SELECT * FROM CAR WHERE car_type = ? ORDER BY license_plate OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String countListCarSearchbyColor = "SELECT COUNT(*) FROM CAR WHERE car_color = ?";

	public final static String getListCarSearchPagingbyColor = "SELECT * FROM CAR WHERE car_color = ? ORDER BY license_plate OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String countListCarSearchbyCompany = "SELECT COUNT(*) FROM CAR WHERE company = ?";

	public final static String getListCarSearchPagingbyCompany = "SELECT * FROM CAR WHERE company = ? ORDER BY license_plate OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String countListCarSearchbyPark = "SELECT COUNT(*) FROM CAR WHERE park_id = ?";

	public final static String getListCarSearchPagingbyPark = "SELECT * FROM CAR WHERE park_id = ? ORDER BY license_plate OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public static final String ADD_TRIP = "INSERT INTO TRIP (destination, depature_date, driver, seat_type, booked_ticket, max_ticket)\r\n"
			+ "VALUES (?, ?, ?, ?, ?, ?)";
	public static final String GET_ALL_TRIPS = "SELECT * FROM TRIP";
	public static final String GET_EMPLOYEE_BY_ACCOUNT = "SELECT * FROM EMPLOYEE\r\n" + "WHERE account = ?";
	public static final String GET_TRIPS_BY_DATE = "SELECT * FROM\r\n"
			+ "(SELECT ROW_NUMBER() over (order by depature_date asc) as r, * FROM TRIP\r\n"
			+ "WHERE CONVERT(date, depature_date) = ?\r\n" + ") as x\r\n" + "WHERE x.r between ? and ?";
	public static final String SEARCH_TRIP_QUERY = "SELECT * FROM\r\n"
			+ "(SELECT ROW_NUMBER() over (order by depature_date asc) as r, * FROM TRIP\r\n"
			+ "WHERE CONVERT(date, depature_date) = ? and destination like ?\r\n" + ") as x\r\n"
			+ "WHERE x.r between ? and ?";
	public static final String GET_TOTAL_TRIPS = "SELECT * FROM TRIP\r\n"
			+ "WHERE CONVERT(date, depature_date) = ? and destination like ?";

	public static final String GET_TRIP_BY_ID = "SELECT * FROM TRIP\r\n" + "WHERE trip_id = ?";
	public static final String GET_LATEST_TRIP = "SELECT * FROM\r\n"
			+ "(SELECT ROW_NUMBER() over (order by depature_date asc) as r, * FROM TRIP\r\n"
			+ "WHERE CONVERT(date, depature_date) = CONVERT(date,(SELECT MAX(depature_date) FROM TRIP))\r\n"
			+ ") as x\r\n" + "WHERE x.r between ? and ?";
	public static final String DELETE_TRIP = "DELETE FROM TICKET\r\n" + "WHERE trip_id = ?\r\n" + "\r\n"
			+ "DELETE FROM BOOK_OFFICE\r\n" + "WHERE trip_id = ?\r\n" + "\r\n" + "DELETE FROM TRIP\r\n"
			+ "WHERE trip_id = ?";

	public static final String EDIT_TRIP = "UPDATE TRIP\r\n" + "SET destination = ?, depature_date = ?,\r\n"
			+ "driver = ?, seat_type = ?, max_ticket = ?\r\n" + "WHERE trip_id = ?";
	public static final String GET_ALL_LICENSE_PLATES = "SELECT license_plate from CAR";
	public static final String ADD_TICKET = "INSERT INTO TICKET(cus_name, booking_time, trip_id, license_plate)\r\n"
			+ "VALUES(?, ?, ?, ?)";
	public static final String GET_LATEST_TICKETDTO = "SELECT * FROM\r\n"
			+ "(SELECT ROW_NUMBER() over(order by x.ticket_id asc) as row_id, x.ticket_id, x.destination, x.license_plate, x.cus_name, x.booking_time, x.depature_date FROM\r\n"
			+ "(SELECT ticket_obj.ticket_id, trip_obj.destination, trip_obj.depature_date, car_obj.license_plate, ticket_obj.cus_name, ticket_obj.booking_time FROM TICKET ticket_obj, TRIP trip_obj, CAR car_obj\r\n"
			+ "WHERE ticket_obj.trip_id = trip_obj.trip_id AND ticket_obj.license_plate = car_obj.license_plate) as x\r\n"
			+ "WHERE CONVERT(date,x.depature_date) = CONVERT(date,(SELECT MAX(Convert(date,t.depature_date)) as maxDate FROM Trip t INNER JOIN Ticket tick ON t.trip_id = tick.trip_id HAVING COUNT(tick.trip_id) > 0))) as tb\r\n"
			+ "WHERE tb.row_id between ? and ?";
	public static final String GET_TICKETDTO_BY_DATE_AND_FILTER = "SELECT * FROM\r\n"
			+ "(SELECT ROW_NUMBER() over(order by x.ticket_id asc) as row_id, x.ticket_id, x.destination, x.license_plate, x.cus_name, x.booking_time, x.depature_date FROM\r\n"
			+ "(SELECT ticket_obj.ticket_id, trip_obj.destination, trip_obj.depature_date, car_obj.license_plate, ticket_obj.cus_name, ticket_obj.booking_time FROM TICKET ticket_obj, TRIP trip_obj, CAR car_obj\r\n"
			+ "WHERE ticket_obj.trip_id = trip_obj.trip_id AND ticket_obj.license_plate = car_obj.license_plate) as x\r\n"
			+ "WHERE CONVERT(date,x.depature_date) = ?" + FILTER_PART + ") as tb\r\n"
			+ "WHERE tb.row_id between ? and ?";
	public static final String GET_NUMBER_OF_SELECTED_TICKETDTO = "SELECT ROW_NUMBER() over(order by x.ticket_id asc) as row_id, x.ticket_id, x.destination, x.license_plate, x.cus_name, x.booking_time, x.depature_date FROM\r\n"
			+ "(SELECT ticket_obj.ticket_id, trip_obj.destination, trip_obj.depature_date, car_obj.license_plate, ticket_obj.cus_name, ticket_obj.booking_time FROM TICKET ticket_obj, TRIP trip_obj, CAR car_obj\r\n"
			+ "WHERE ticket_obj.trip_id = trip_obj.trip_id AND ticket_obj.license_plate = car_obj.license_plate) as x\r\n"
			+ "WHERE CONVERT(date,x.depature_date) = ?" + FILTER_PART;
	public static final String DELETE_TICKET = "DELETE FROM TICKET WHERE ticket_id = ?";
	
	public static final String DELETE_EMPLOYEE = "DELETE FROM EMPLOYEE WHERE employee_id = ?";

	public final static String randomText = "text";

	public final static String getListCarPaging = "SELECT * FROM CAR ORDER BY license_plate OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String countListCar = "SELECT COUNT(*) FROM CAR";

	public final static String addCar = "INSERT INTO CAR VALUES ( ? , ? , ? , ? , ?) ";

	public final static String getParkingLot = "SELECT * FROM PARKINGLOT";

	public final static String deleteCar = "DELETE TICKET WHERE license_plate = ? DELETE CAR WHERE license_plate = ?";

	public final static String updateCar = "UPDATE [dbo].[CAR] SET [car_type] = ? ,[car_color] = ? ,[company] = ? ,[park_id] = ? WHERE license_plate = ?";

	public final static String getCarbyLicense = "SELECT * FROM CAR WHERE license_plate = ?";

	public final static String countListCarSearch = "SELECT COUNT(*) FROM CAR WHERE " + randomText + " like ?";

	public final static String getListCarSearchPaging = "SELECT * FROM CAR WHERE " + randomText
			+ " like ? ORDER BY license_plate OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String addEmployee = "INSERT INTO EMPLOYEE(full_name , dob , sex , address , phone_number , email , account , password ,department) VALUES (?,?,?,?,?,?,?,?,?)";

	public final static String countListEmployee = "SELECT COUNT(*) FROM EMPLOYEE";

	public final static String getListEmployeePaging = "SELECT * FROM EMPLOYEE ORDER BY employee_id OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String countListEmployeeSearch = "SELECT COUNT(*) FROM EMPLOYEE WHERE " + randomText
			+ " like ?";

	public final static String getListEmployeeSearchPaging = "SELECT * FROM EMPLOYEE WHERE " + randomText
			+ " like ? ORDER BY employee_id OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String viewEmployee = "SELECT * FROM EMPLOYEE WHERE employee_id = ?";

	public final static String getBookOfficeList = "select * from CAR_PARK.dbo.BOOK_OFFICE";

	public final static String AddBookOffice = "INSERT INTO CAR_PARK.dbo.BOOK_OFFICE VALUES ( ?, ?, ?, ?, ?, ?, ?)";

	public final static String geTripList = "select * from CAR_PARK.dbo.Trip";

	public final static String getBookOfficeWithDestination = "Select bookoffice_id, bookoffice_name, destination \r\n"
			+ "FROM CAR_PARK.dbo.BOOK_OFFICE inner join Car_Park.dbo.TRIP \r\n"
			+ "ON CAR_PARK.dbo.BOOK_OFFICE.trip_id = Car_Park.dbo.TRIP.trip_id \r\n"
			+ "ORDER BY bookoffice_id OFFSET ? ROWS FETCH NEXT ? ROWS ONLY\r\n";

	public final static String countListBooking = "SELECT COUNT(*) FROM CAR_PARK.dbo.BOOK_OFFICE";

	public final static String countBookOfficeBySearch = "SELECT COUNT(*) FROM CAR_PARK.dbo.BOOK_OFFICE WHERE "
			+ STRING_TO_REPLACE + " LIKE ?";

	public final static String getBookOfficeWithDestinationSearch = "Select bookoffice_id, bookoffice_name, destination "
			+ "FROM CAR_PARK.dbo.BOOK_OFFICE inner join Car_Park.dbo.TRIP "
			+ "ON CAR_PARK.dbo.BOOK_OFFICE.trip_id = Car_Park.dbo.TRIP.trip_id " + "WHERE " + STRING_TO_REPLACE
			+ " LIKE ? " + "ORDER BY bookoffice_id OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

	public final static String getBookOfficeFromID = "SELECT * FROM CAR_PARK.dbo.BOOK_OFFICE WHERE trip_id = ?";
	
	public final static String getDestinationFromID = "SELECT destination FROM CAR_PARK.dbo.TRIP WHERE trip_id = ?";
}
