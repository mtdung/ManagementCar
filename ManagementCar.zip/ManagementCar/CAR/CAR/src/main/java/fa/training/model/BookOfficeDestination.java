/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fa.training.model;

/**
 *
 * @author Bau
 */
public class BookOfficeDestination {
    int id;
    String name, destination;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public BookOfficeDestination() {
    }

    @Override
    public String toString() {
        return "BookOfficeDestination{" + "id=" + id + ", name=" + name + ", destination=" + destination + '}';
    }
    
    
}
