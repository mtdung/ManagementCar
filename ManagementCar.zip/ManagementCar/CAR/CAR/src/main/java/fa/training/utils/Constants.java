package fa.training.utils;

public class Constants {
	public static final int PAGE_SIZE = 3;
	public static final int FIRST_PAGE = 1;
	public static final String[] ADMIN_JSP_PAGES = { "AddEmployee.jsp", "EmployeeList.jsp", "ViewEmployee.jsp" };
	public static final String[] NOT_LOGGED_PAGE = { "Login.jsp" };
	public static final String[] EMPLOYEE_JSP_PAGES = { "/views/AddBookingOffice.jsp", "/views/AddCar.jsp",
			"/views/AddParking.jsp", "/views/AddTicket.jsp", "/views/AddTrip.jsp", "/views/CarList.jsp",
			"/views/EditParking.jsp", "/views/EditTrip.jsp", "/views/ParkingLotList.jsp", "/views/TicketList.jsp",
			"/views/TripList.jsp", "/views/UpdateCar.jsp", "/views/ViewBookingOffice.jsp",
			"/views/viewOneBookOffice.jsp" };
}
