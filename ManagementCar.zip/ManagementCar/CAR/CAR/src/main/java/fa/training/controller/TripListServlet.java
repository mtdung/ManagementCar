package fa.training.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fa.training.dao.TripDAO;
import fa.training.dao.impl.*;
import fa.training.model.Employee;
import fa.training.model.Trip;
import fa.training.utils.Constants;

/**
 * Servlet implementation class TripListServlet
 */
@WebServlet("/TripListServlet")
public class TripListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TripListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		int loginStatus = 0;
		Employee selectedEmployee = (Employee) session.getAttribute("employee");
		if (selectedEmployee == null) {
			request.setAttribute("generalAlert", "You haven't logged in yet!");
		} else if (selectedEmployee.getDept().equals("Admin")) {
			loginStatus = 2;
		} else {
			loginStatus = 1;
			try {
				TripDAO tripDAO = new TripDAOImpl();
				if (request.getParameter("isReloaded") == null) {
					int selectedPage = 1;
					List<Trip> tripList = tripDAO.getLatestTripsWithPaging(selectedPage, Constants.PAGE_SIZE);
					if (tripList.isEmpty()) {
						request.setAttribute("generalAlert", "There's no trips!");
					} else {
						Date selectedDate = Date
								.valueOf(tripList.get(0).getDeparture_date().toLocalDateTime().toLocalDate());
						int numberOfSelectedTrips = tripDAO.getNumberOfTrips(selectedDate, "");
						int numberOfPages = numberOfSelectedTrips % Constants.PAGE_SIZE == 0
								? numberOfSelectedTrips / Constants.PAGE_SIZE
								: numberOfSelectedTrips / Constants.PAGE_SIZE + 1;
						request.setAttribute("tripList", tripList);
						request.setAttribute("selectedPage", selectedPage);
						request.setAttribute("numberOfPages", numberOfPages);
						request.setAttribute("destination", "");
						request.setAttribute("totalTripsOnPage", tripList.size());
						request.setAttribute("day",
								tripList.get(0).getDeparture_date().toLocalDateTime().getDayOfMonth());
						request.setAttribute("month",
								tripList.get(0).getDeparture_date().toLocalDateTime().getMonthValue());
						request.setAttribute("year", tripList.get(0).getDeparture_date().toLocalDateTime().getYear());
					}
				} else {
					int selectedPage = Integer.parseInt(request.getParameter("selectedPage"));
					String destination = request.getParameter("destination");
					int day = Integer.parseInt(request.getParameter("day"));
					int month = Integer.parseInt(request.getParameter("month"));
					int year = Integer.parseInt(request.getParameter("year"));
					Date selectedDate = Date.valueOf(LocalDate.of(year, month, day));
					int numberOfPages = Integer.parseInt(request.getParameter("numberOfPages"));
					List<Trip> tripList = tripDAO.searchTrip(selectedDate, destination, selectedPage,
							Constants.PAGE_SIZE);
					if (tripList.isEmpty()) {
						request.setAttribute("generalAlert", "No trips to display!");
					} else {
						request.setAttribute("tripList", tripList);
						request.setAttribute("selectedPage", selectedPage);
						request.setAttribute("numberOfPages", numberOfPages);
						request.setAttribute("totalTripsOnPage", tripList.size());
					}
					request.setAttribute("destination", destination);
					request.setAttribute("day", day);
					request.setAttribute("month", month);
					request.setAttribute("year", year);
				}
			} catch (Exception ex) {
				request.setAttribute("generalAlert", "Error occured!");
			}
		}
		switch (loginStatus) {
		case 0:
			request.getRequestDispatcher("views/Login.jsp").forward(request, response);
			break;
		case 1:
			request.getRequestDispatcher("views/TripList.jsp").forward(request, response);
			break;
		default:
			request.getRequestDispatcher("listemployee").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int day = Integer.parseInt(request.getParameter("day"));
		int month = Integer.parseInt(request.getParameter("month"));
		int year = Integer.parseInt(request.getParameter("year"));
		Date selectedDate = Date.valueOf(LocalDate.of(year, month, day));
		String destination = request.getParameter("destination");
		int pageSize = 3;
		int selectedPage = 1;
		try {
			TripDAO tripDAO = new TripDAOImpl();
			List<Trip> tripList = tripDAO.searchTrip(selectedDate, destination, selectedPage, pageSize);
			if (tripList.isEmpty()) {
				request.setAttribute("generalAlert", "No trips found!");
			} else {
				int numberOfSelectedTrips = tripDAO.getNumberOfTrips(selectedDate, destination);
				int numberOfPages = numberOfSelectedTrips % pageSize == 0 ? numberOfSelectedTrips / pageSize
						: numberOfSelectedTrips / pageSize + 1;
				request.setAttribute("tripList", tripList);
				request.setAttribute("selectedPage", selectedPage);
				request.setAttribute("numberOfPages", numberOfPages);
				request.setAttribute("totalTripsOnPage", tripList.size());
			}
			request.setAttribute("destination", destination);
			request.setAttribute("day", day);
			request.setAttribute("month", month);
			request.setAttribute("year", year);
		} catch (Exception e) {
			request.setAttribute("generalAlert", "Error occured!");
		} finally {
			request.getRequestDispatcher("views/TripList.jsp").forward(request, response);
		}
	}

}
